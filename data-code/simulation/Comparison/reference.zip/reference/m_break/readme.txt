This is a direct and complete translation of the Gauss codes of Bai, J. and P. Perron (1998) "Estimating and Testing Linear 
Models with Multiple Structural Changes" Econometrica, vol 66, 47-78 and Bai, J. and P. Perron (2003) "Computation and Analysis 
of Multiple Structural Change Models" Journal of Applied Econometrics, 18, 1-22, provided by Pierre Perron (version 3, October 
11, 2004). All the notice in the original Gaiss codes remain valid.

For users, run "brcode.m". The procedure is explained in the same m file and in each function file.

June 20, 2012
Yohei Yamamoto
Email: yohei.yamamoto@econ.hit-u.ac.jp