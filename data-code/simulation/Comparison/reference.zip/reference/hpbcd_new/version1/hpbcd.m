function d = hpbcd(y,x,N,lambda,XTol,maxIter)
% The block coordinated descent algorithm for heterogenous panel data model
% Inputs:
%   y = [y_1;y_2;...;y_T], where y_t = [y_1t;y_2t;...,y_Nt];
%   x = [x_1;x_2;...;x_T], where x_t = [x_1t;x_2t;...,x_Nt]; a NT-by-p matrix
%   N:    number of individuals
%   lambda: tuning parameter
%   XTol: Tolerance of error (default: 1e-4)
%   maxIter: max number of iterations (default: 400)
% Output:
%   d: NT-by p matrix of theta, theta_1 = beta_1, theta_2 =
%   beta_2-beta_1..., where beta_t is Np-by-1 vector.
%
[n,p] = size(x);
T = n/N;

if nargin<5 || isempty(XTol)
    XTol = 1e-4; 
end

if nargin<6 || isempty(maxIter)
    maxIter = 400;
end

dx = zeros(N*(T-1),p);
dy = zeros(N*(T-1),1);
for t=2:T
    dx((t-2)*N+1:(t-1)*N,:) = x((t-1)*N+1:t*N,:) - x((t-2)*N+1:(t-1)*N,:);
    dy((t-2)*N+1:(t-1)*N,:) = y((t-1)*N+1:t*N,:) - y((t-2)*N+1:(t-1)*N,:);
end
xx = zeros(N*(T-1),p*p);
dxdx = zeros(N*(T-1),p*p);
dxx = zeros(N*(T-1),p*p);
dxdy = zeros(N*(T-1),p);
xdy = zeros(N*(T-1),p);
for t=1:T-1
    for i=1:N
        xx((t-1)*N+i,:)=reshape(x(t*N+i,:)'*x(t*N+i,:),1,p*p);
    end
end
for t=1:T-1
    for i=1:N
        dxdx((t-1)*N+i,:)=reshape(dx((t-1)*N+i,:)'*dx((t-1)*N+i,:),1,p*p);
        dxx((t-1)*N+i,:)=reshape(dx((t-1)*N+i,:)'*x(t*N+i,:),1,p*p);
        dxdy((t-1)*N+i,:)=reshape(dx((t-1)*N+i,:)'*dy((t-1)*N+i,:),1,p);
        xdy((t-1)*N+i,:)=reshape(x(t*N+i,:)'*dy((t-1)*N+i,:),1,p);
    end
end
S_dxdy = zeros(N*(T-1),p);
S_dxdx = zeros(N*(T-1),p*p);
for t=1:T-1
    S1 = zeros(N,p);
    S2 = zeros(N,p*p);
    for tt = 1:t
        S1 = S1 + dxdy((T-tt-1)*N+1:(T-tt)*N,:);
        S2 = S2 + dxdx((T-tt-1)*N+1:(T-tt)*N,:);       
    end
    S_dxdy((T-t-1)*N+1:(T-t)*N,:) = S1;
    S_dxdx((T-t-1)*N+1:(T-t)*N,:) = S2;
end

d0 = zeros(T*N*p,1);
d1 = zeros(T*N*p,1);

e = 1e10;
i = 0;
while e>XTol && i<maxIter
    i = i + 1;
    for t = 1:T
        if t == 1
            r = reshape(S_dxdy(1:N,:)',N*p,1);
            for tt=2:T
                for ii = 1:N
                    r((ii-1)*p+1:ii*p) = r((ii-1)*p+1:ii*p) - reshape(dxx((tt-2)*N+ii,:),p,p)*d0(((tt-1)*N+ii-1)*p+1:((tt-1)*N+ii)*p);
                end
            end
            for tt=3:T
                beta = zeros(N*p,1);
                for ss = 2:tt-1
                    beta = beta+d0((ss-1)*N*p+1:ss*N*p);
                end
                for ii = 1:N
                    r((ii-1)*p+1:ii*p) = r((ii-1)*p+1:ii*p) - reshape(dxdx((tt-2)*N+ii,:),p,p)*beta((ii-1)*p+1:ii*p);
                end
            end
            for ii=1:N
                d1((ii-1)*p+1:ii*p) = reshape(S_dxdx(ii,:),p,p)\r((ii-1)*p+1:ii*p);
            end
        else
            g = reshape(xdy((t-2)*N+1:(t-1)*N,:)',N*p,1);% N*p-by-1
            beta = zeros(N*p,1);
            for ss = 1:t-1
                beta = beta+d1((ss-1)*N*p+1:ss*N*p);
            end
            for ii = 1:N
                g((ii-1)*p+1:ii*p) = g((ii-1)*p+1:ii*p) - reshape(dxx((t-2)*N+ii,:),p,p)'*beta((ii-1)*p+1:ii*p) ;
            end
            if t < T
                g = g + reshape(S_dxdy((t-1)*N+1:t*N,:)',N*p,1);
                for tt = t+1:T
                    for ii = 1:N
                        g((ii-1)*p+1:ii*p) = g((ii-1)*p+1:ii*p) - reshape(dxx((tt-2)*N+ii,:),p,p)*d0(((tt-1)*N+ii-1)*p+1:((tt-1)*N+ii)*p);
                    end
                    beta = zeros(N*p,1);
                    for ss = 1:t-1
                        beta = beta+d1((ss-1)*N*p+1:ss*N*p);
                    end
                    for ss = t+1:tt-1
                        beta = beta+d0((ss-1)*N*p+1:ss*N*p);
                    end
                    for ii = 1:N
                        g((ii-1)*p+1:ii*p) = g((ii-1)*p+1:ii*p) - reshape(dxdx((tt-2)*N+ii,:),p,p)*beta((ii-1)*p+1:ii*p);
                    end
                end
            end
            if norm(g)<=lambda
                d1((t-1)*N*p+1:t*N*p) = 0;
            else
                g = -g;
                R = zeros(N*p,N*p);
                for ii = 1:N
                    R((ii-1)*p+1:ii*p,(ii-1)*p+1:ii*p) = R((ii-1)*p+1:ii*p,(ii-1)*p+1:ii*p) + reshape(xx((t-2)*N+ii,:),p,p);
                    if t < T
                        R((ii-1)*p+1:ii*p,(ii-1)*p+1:ii*p) = R((ii-1)*p+1:ii*p,(ii-1)*p+1:ii*p) + reshape(S_dxdx((t-1)*N+ii,:),p,p);
                    end
                end
                [gam,fval,exitflag] = fminsearch(@myfun2,1/N,[],R,lambda,g);
%                [gam,fval,exitflag] = fminbnd(@myfun2,0,10,[],R((t-1)*p+1:t*p,(t-1)*p+1:t*p),lambda,g);
%                [gam,fval,exitflag] = fzero(@myfun,[0;1],[],R((t-1)*p+1:t*p,(t-1)*p+1:t*p),lambda,g);
                if exitflag==1
                    d1((t-1)*N*p+1:t*N*p) = -gam*((gam*R + lambda^2/2*eye(N*p))\g);
                else
                    disp('Line search failed');
                    d = reshape(d1,p,N*T)';
                    return;
                end
            end
        end
    end
    e = norm(d1-d0);
    d0 = d1;
%    disp([i e])
end
d = reshape(d1,p,N*T)';

function y = myfun(gam,R,lam,g)
p = length(g);
tmp=lam/2 * ((gam*R+lam^2/2*eye(p))\g);
y =  sum(tmp.^2) - 1;

function y = myfun2(gam,R,lam,g)
if gam<0
    y=1e10;
    return;
end
p = length(g);
y = gam*(1-1/2*g'*((gam*R+lam^2/2*eye(p))\g));


