function [regime,beta,Sigma,ssr,s2]=hp_simple(y,x,N,lambda)
% Easy version 
[n,p]=size(x);
T = n/N;

d = hpbcd(y,x,N,lambda);
tht = zeros(T,N*p);
for i=1:p
    tht(:,(i-1)*N+1:i*N)=reshape(d(:,1),N,T)';
end
regime = findbreaks(tht);
[beta,Sigma,ssr,s2] = hppost(y,x,regime);
