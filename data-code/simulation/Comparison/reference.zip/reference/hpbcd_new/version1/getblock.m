function A=getblock(R,M,N,m,n,nrow,ncol)
A = zeros(nrow,ncol);
for i=0:nrow-1
    for j=0:ncol-1
        A(j*nrow+i+1)=R((n+j)*M+m+i+1);
    end
end

