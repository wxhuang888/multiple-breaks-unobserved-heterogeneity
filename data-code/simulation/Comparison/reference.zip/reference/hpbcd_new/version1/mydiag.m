function A = mydiag(x)

[p,n] = size(x);
A = zeros(n*p,n);
for i=1:n
    A((i-1)*p+1:i*p,i)=x(:,i);
end
