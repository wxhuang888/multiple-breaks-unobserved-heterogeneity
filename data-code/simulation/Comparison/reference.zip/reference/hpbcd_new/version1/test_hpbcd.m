%test hpbcd.m

N = 30;
T = 30;
p = 2;
beta = [ones(T/3,1);-ones(T/3,1);ones(T/3,1)];
x = [randn(N*T,1) randn(N*T,1)];
u = randn(N,1);
y = sum(x.*kron(beta,ones(N,p)),2)+repmat(u,T,1)+0.5*randn(N*T,1);
%save testdata
%load testdata

weight=ones(T,1);
XTol=1e-4;
maxIter=40;
lambda = 25;

%profile on;
tht = hpbcd(y,x,N,lambda);
%tht = mhpbcd(y,x,N,lambda);
%profile viewer
theta = reshape(tht(:,1),N,T)';
figure(1),plot(cumsum(theta));
%disp(norm(tht1-tht2));


