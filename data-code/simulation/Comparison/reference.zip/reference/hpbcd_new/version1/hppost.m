function [beta,Sigma,ssr,s2] = hppost(y,x,regime)

[n,p] = size(x);

m = length(regime)-2;
T = regime(m+2)-1;
N = n/T;

dx = zeros(N*(T-1),p);
dy = zeros(N*(T-1),1);
for t=2:T
    dx((t-2)*N+1:(t-1)*N,:) = x((t-1)*N+1:t*N,:) - x((t-2)*N+1:(t-1)*N,:); % N-by-p
    dy((t-2)*N+1:(t-1)*N,:) = y((t-1)*N+1:t*N,:) - y((t-2)*N+1:(t-1)*N,:);
end

C = zeros(N*p*(m+1),N*(T-1));

for j=1:m+1
    for t=regime(j)+1:regime(j+1)-1
        dxt = dx((t-2)*N+1:(t-1)*N,:)';
        mdxt = feval(@mydiag,dxt);%Np-by-N
        C((j-1)*N*p+1:j*N*p,(t-2)*N+1:(t-1)*N)=mdxt;
    end
end
for j=1:m
    xt = x((regime(j+1)-2)*N+1:(regime(j+1)-1)*N,:)';
    mxt = feval(@mydiag,xt);
    C((j-1)*N*p+1:j*N*p,(regime(j+1)-2)*N+1:(regime(j+1)-1)*N)=-mxt;
end
for j=2:m+1
    xt = x((regime(j)-1)*N+1:regime(j)*N,:)';
    mxt = feval(@mydiag,xt);
    C((j-1)*N*p+1:j*N*p,(regime(j)-2)*N+1:(regime(j)-1)*N)=mxt;
end
C = C'; 
Q = C'*C;
R = C'*dy;
if p*(m+1)>=(T-1)
    disp('The number of unknown parameters exceeds the number of equations. Regularized solution is obtained.');
    Q = Q+1e-10*eye(N*p*(m+1));
end
beta = Q\R; % N*p*(m+1)-by-1

du = dy-C*beta;
ssr = du'*du;
s2 = ssr/(N*(T-1)-N*p*(m+1));
B = zeros(N*(T-1),N*T);
for t=1:T-1
    B((t-1)*N+1:t*N,(t-1)*N+1:t*N) = -eye(N);
    B((t-1)*N+1:t*N,t*N+1:(t+1)*N) = eye(N);
end
Qinv = Q\eye(N*p*(m+1));
%Sigma = s2*Qinv;
Sigma = Qinv*C'*(B*B')*C*Qinv'*s2/2;
%Sigma2 = Qinv * (C'*(C.*repmat(du.^2,1,N*p*(m+1)))*N*(T-1)/(N*(T-1)-N*p*(m+1))) * Qinv;


