% test hp_simple

N = 30;
T = 30;
p = 2;

regime0 = [1; fix(T/3)+1; fix(T*2/3)+1;T+1];
alpha0 = [1 2;...
         -1 -2;...
          3 4];
beta0 = kron(alpha2beta(alpha0,regime0),ones(N,1));

x = [randn(N*T,1) randn(N*T,1)];
u = randn(N,1);
y = sum(x.*beta0,2)+repmat(u,T,1)+0.5*randn(N*T,1);

weight=ones(T,1);
XTol=1e-4;
maxIter=40;
lambda = 25;

[regime,alpha,Sigma,ssr,s2]=hp_simple(y,x,N,lambda);
m = length(regime)-2;

% retrieve the coefficients from the most recent regime
alpha = reshape(alpha,p,N*(m+1))';
a = zeros(N,p);
for i=1:p
    tmp = reshape(alpha(:,i),N,m+1); % N*(m+1);
    a(:,i)=tmp(:,m+1);
end

% To predict y(T+1), given x(T+1):
x0 = randn(N,p); % the predictor
xr = zeros(N,p); % the most recent observation of x
for i=1:p
    tmp = reshape(x(:,i),N,T);
    xr(:,i) = tmp(:,T);
end
dx = xr-x0;
dy = sum(dx*a,2);

tmp = reshape(y,N,T);
yr = tmp(:,T); % the most recent observation of y
yhat = yr + sum(dx.*a,2); % prediction 

disp(['The number of breaks is ' num2str(m)])
disp(regime(2:m+1)');
disp('The prediction of y')
disp(yhat)
