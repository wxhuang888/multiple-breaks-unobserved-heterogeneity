function [regime,ts]=findbreaks(tht,h)

if nargin < 2 || isempty(h)
    h = 1;
end

n = size(tht,1);
thn = norms(tht,2,2);
theta = thn(2:n);
ts = zeros(n-1,1);
for i=1:n-1
    for j=1:n-1
        ts(i) = ts(i)+normpdf((j-i)/h)*theta(j);
    end
end
[pks,locs] = findpeaks(ts,(2:n)');
regime = [1;locs;n+1];
    