%test hpbcd.m

N = 40;
T = 40;
p = 2;
beta = [ones(T/2,1);ones(T/2,1)];
X = randn(N*T,p);
u = randn(N,1);
Y = sum(X.*kron(beta,ones(N,p)),2)+repmat(u,T,1)+0.5*randn(N*T,1);
beta0 = [ones(N,1) -ones(N,1)];

regime = [1 T+1]';
m = length(regime)-2;
[a,Sigma] = hppost(Y,X,regime);

a = reshape(a,p,N*(m+1))';
se = sqrt(diag(Sigma));
se = reshape(se,p,N*(m+1))';
tstat = a./se;
dof = N*(T-1)-N*p*(m+1);
pv = 2*(1-tcdf(abs(tstat),dof));
%disp(beta);
disp([a se pv])
