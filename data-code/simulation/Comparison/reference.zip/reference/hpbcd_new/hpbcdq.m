function [theta,gamma] = hpbcdq(y,x,N,z,lambda,weight,XTol,maxIter)
% This function wraps up hpbcd_C, the mex implementation of the block 
%   coordinated descent algorithm for the LS estimation of heterogenous 
%   panel model: y_it = x_it * beta_it + z_it * gamma + u_it
% 
%  [theta,gamma] = hpbcdq(y,x,N,z,lambda,weight,XTol,maxIter)
%  Inputs:
%      y: lhs variable, an NT by 1 column vector
%      x: rhs variables, an NT by p matrix, each column corresponds to a
%           regressor
%      z: rhs variables, an NT by q matrix, each column corresponds to a
%           regressor
%      lambda: tuning parameter, scalar
%      weight: a (T-1)-by-1 weighting vector (default: ones(T-1,p))
%      XTol: a scalar error tolerance (default: 1e-4)
%      maxIter: an integer of the max num of iterations (default: 400)
%  Outputs:
%      theta: a NT-by-p matrix of theta. 
%      gamma: q-by-1 vector.
%  Note: the mex program is compiled on 64-bit Windows 7. To make it work 
%   on other platforms, you need to recompile the code using Matlab.To 
%   compile mex program, first make sure you have a compiler with which 
%   your Matlab is compatible. Then enter the following command:
%      >> mex hpbcd_C.c nrutil.c mnbrak.c brent.c gaussj.c
%
%  Junhui Qian
%  Feb 15, 2023
%  junhuiq@gmail.com

n = size(x,1);
T = n/N;
if nargin<4 || isempty(z)
    z=[];
end

if nargin<6 || isempty(weight)
    weight = ones(T-1,1); 
end

if nargin<7 || isempty(XTol)
    XTol = 1e-4; 
end

if nargin<8 || isempty(maxIter)
    maxIter = 400;
end

[tht,gamma]=hpbcd_C(y,x,N,z,lambda,weight,XTol,maxIter);
theta = tht';