function [regime,alpha,Sigma,ze,Sigma_ze,fe,beta,ssr,s2,residual] = hpanel(y,x,N,lambda,z,fetype,weight,XTol,maxIter)
% [regime,alpha,Sigma,beta,fe,ssr,s2,residual] = hpanel(y,x,N,z,fetype,lambda,weight,XTol,maxIter)
% Estimate a fixed-effect model with heterogenous coefficients:
%   y_it = mu_i + g_t + x_it'beta_it + z_it'gamma + u_it, i=1,...,N, t=1,...,T
%   Inputs:
%       y : dependent variable, y=[y_1;y_2;...;y_T], where y_t = [y_1t;y_2t;...,y_Nt];
%       x : regressor with heterogenous and possibly time-varying effects on y, x = [x_1;x_2;...;x_T], where x_t = [x_1t;x_2t;...,x_Nt]; a NT-by-p matrix
%       N : number of individuals
%       lambda : tuning parameter
%       z : (optional) regresor with homogenous and time-invariant effects on y, z = [z_1;z_2;...;z_T], where z_t = [z_1t;z_2t;...,z_Nt]; a NT-by-q matrix
%       fetype : (optional) an integer indicating the type of fixed effects
%           if fetype = 0, no fixed effects
%           if          1, one-way fixed effects (only individual fe, default)
%                       2, two-way fixed effects
%                       3, one-way fixed effects (only time fe)
%       weight : (optional) a (rarely used) weighting vector, (T-1)-by-1 vector.
%       XTol : (optional) Tolerance of error (default: 1e-4)
%       maxIter : (optional) max number of iterations (default: 400)
% Output:
%       regime : a vector indicating structural changes regime = [1 T1+1 T2+1 ... Tm+1 T+1]', where (Tj+1)'s represents the j-th break date;
%       alpha : the (heterogenous and possibly time-varying) effect of x on
%           y, alpha is a (m+1)N-by-p matrix
%       Sigma : the (m+1)Np-by-(m+1)Np cov matrix of alpha
%       beta :  the extended version of alpha, a TN-by-p matrix
%       fe :  estimated fixed effects
%       ssr : sum of squared residuals
%       s2 : estimated variance of errors
%       residual: estimated residuals
%   Junhui Qian
%   2023.6.10


[n,p] = size(x);
T = n/N;

if nargin<5 || isempty(z)
    z = []; 
    ze = [];
    Sigma_ze = [];
end

if nargin<6 || isempty(fetype)
    fetype = 1; 
end

if nargin<7 || isempty(weight)
    weight = ones(T-1,1); 
end

if nargin<8 || isempty(XTol)
    XTol = 1e-4; 
end

if nargin<9 || isempty(maxIter)
    maxIter = 400;
end

switch fetype
    case 0,% no individual or time effects
        Z = z;% do nothing
    case 1, % only individual effects
        Z = [z repmat(eye(N),T,1)];
    case 2, % two-way effects
        te = kron(eye(T),ones(N,1));
        Z = [z repmat(eye(N),T,1) te(:,1:T-1)];
    case 3, % one-way effects, only time effects
        Z = [z kron(eye(T),ones(N,1))];
end

tht = hpbcdq(y,x,N,Z,lambda,weight,XTol,maxIter);
%tht = hpbcds(y,x,N,Z,lambda,weight,XTol,maxIter);
theta = reshape(tht(:,1),N,T)';
regime=findbreaks(theta,[],p);

m = length(regime) - 2;
[alpha,Sigma,fe,Sigma_fe,ssr,s2,beta,residual] = hppost(y,x,Z,regime);
alpha = reshape(alpha,p,N*(m+1))';

q = size(z,2);
if q>0
    ze = fe(1:q);
    Sigma_ze = Sigma_fe(1:q,1:q);
end

