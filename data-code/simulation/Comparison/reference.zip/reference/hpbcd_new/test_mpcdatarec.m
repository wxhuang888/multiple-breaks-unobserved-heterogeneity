clear all;

mpc_num = xlsread('mpcdata.xlsx');
[T1,N1] = size(mpc_num);

year = mpc_num(:,1);
N = (N1-1)/2;

income = mpc_num(:,2:2:N1);
consumption = mpc_num(:,3:2:N1);

T = T1-1;
tt = (1:T)'/T;
y = reshape(log(consumption(1:T,:))',N*T,1);
x1 = reshape(log(income(1:T,:))',N*T,1);
x = [x1 kron(tt,ones(N,1))];

lambda = 10;

%[regime,alpha,S,beta,mu,s2] = hpanel(y,x,N,lambda);
fetype = 1;
[regime,alpha,S,~,~,mu,beta] = hpanel(y,x,N,lambda,[],fetype);
m = length(regime)-2;
disp(year(regime(2:m+1)));

figure(1), plot((2005:2021)',reshape(beta(:,1),N,T)'), title('MPC (Chinese Provinces)');

a1 = reshape(alpha(:,1),N,m+1);
a2 = reshape(alpha(:,2),N,m+1);
a = [a1(:,m+1) a2(:,m+1)]; % N by p

yp0 = log(consumption(T+1,:))'; % N by 1
x1p = log(income(T+1,:))'; % N by 1
ttp = (T+1)/T;
yp = x1p .* a(:,1) + ttp*a(:,2) + mu; % N by 1

figure(2), plot(yp0,yp,'.')
yp0(isnan(yp0))=yp(isnan(yp0)); % replace NaN with predicted values

% Run full-sample regression
yf = [y;yp0];
xf = [x;[x1p ttp*ones(N,1)]];

%[alpha2,Sigma,ze,~,ssr,s2,beta,residual] = hppost(yf,xf,repmat(eye(N),T+1,1),regime2);
[regime2,alpha2,S2,~,~,mu2,beta2,ssr,s2,residual] = hpanel(yf,xf,N,lambda,[],fetype);
m = length(regime2)-2;

alpha2 = reshape(alpha2,2,N*(m+1))'; %N(m+1) by p
se2 = sqrt(diag(S2));
se2 = reshape(se2,2,N*(m+1))';
tstat = alpha2./se2;
dof = N*(T+1)-N*2*(m+1);
pv = 2*(1-tcdf(abs(tstat),dof));
%disp([alpha2 se pv])

mpc = reshape(alpha2(:,1),N,m+1);
mpc_se =  reshape(se2(:,1),N,m+1);
disp(year(regime(2:m+1)));
disp([mpc mpc_se])
figure(3), plot((2005:2022)',reshape(beta2(:,1),N,T+1)');
figure(4), plot(residual)

growth_y = reshape(diff(reshape(yf,N,T+1)')',N*T,1);
growth_x = reshape(diff(reshape(xf(:,1),N,T+1)')',N*T,1);

fetype  = 2; lambda = 0.02;
[regime3,alpha3,S3,~,~,mu3,beta3,ssr,s2,residual] = hpanel(growth_y,growth_x,N,lambda,[],fetype);
m = length(regime3)-2;
se3 = sqrt(diag(S3));
tstat = alpha3./se3;
dof = N*T-N*(m+1);
pv = 2*(1-tcdf(abs(tstat),dof));
disp([alpha3 se3 pv])
disp(year(regime3(2:m+1)));

figure(5), plot((2006:2022)',reshape(beta3,N,T)');
figure(6), plot(residual)

