% test hp_simple

N = 30;
T = 60;
p = 2;
q = 2;

regime0 = [1; fix(T/3)+1; fix(T*2/3)+1;T+1];
alpha0 = [1 -1;...
         -1 0;...
          0.5 -0.5];
beta0 = kron(alpha2beta(alpha0,regime0),ones(N,1));
gamma0 = ones(q,1);

f = randn(T,1); % a macro factor

x = randn(N*T,p);
z = randn(N*T,q);
mu0 = randn(N,1);
g0 = randn(T,1);

sigma = 0.5;
y1 = sum(x.*beta0,2)+repmat(mu0,T,1)+sigma*randn(N*T,1); % one-way fe
y2 = sum(x.*beta0,2)+repmat(mu0,T,1)+kron(g0,ones(N,1))+sigma*randn(N*T,1); % two-way fe
y3 = sum(x.*beta0,2)+z*gamma0+repmat(mu0,T,1)+kron(g0,ones(N,1))+sigma*randn(N*T,1); % two-way fe
y4 = sum(x.*beta0,2)+z*gamma0+kron(g0,ones(N,1))+sigma*randn(N*T,1); % one-way time effect

weight=ones(T-1,1);
XTol=1e-4;
maxIter=100;
lambda = 20;

figure(1)
fetype = 1;
[regime1,alpha1,Sigma1,~,~,~,beta1,ssr1,s1,resl] = hpanel(y1,x,N,lambda,[],fetype);
disp('Estimate a one-way fe panel data model with structural breaks and heterogenous effects')
disp(regime1');
disp('Norm error')
disp(norm(beta1-beta0)/sqrt(N*T));
subplot(221), plot(reshape(beta1(:,1),N,T)')

fetype = 2;
[regime2,alpha2,Sigma2,~,~,~,beta2,ssr2,s2,res2] = hpanel(y2,x,N,lambda,[],fetype);
disp('Estimate a two-way fe panel data model with structural breaks and heterogenous effects')
disp(regime2');
disp('Norm error')
disp(norm(beta2-beta0)/sqrt(N*T));
subplot(222), plot(reshape(beta2(:,1),N,T)')

fetype = 2;
[regime3,alpha3,Sigma3,ze,Sigma_ze,~,beta3,ssr3,s3,res3] = hpanel(y1,x,N,lambda,z,fetype);
disp('Estimate a two-way fe panel data model with structural breaks and heterogenous effects')
disp(regime3');
disp('Norm error')
disp(norm(beta3-beta0)/sqrt(N*T));
subplot(223), plot(reshape(beta3(:,1),N,T)')
disp('The time-invariant effect of z')
se_z = sqrt(diag(Sigma_ze));
disp([ze se_z])

fetype = 3;
[regime4,alpha4,Sigma4,ze4,Sigma_ze4,~,beta4,ssr4,s4,res4] = hpanel(y4,x,N,lambda,z,fetype);
disp('Estimate a two-way fe panel data model with structural breaks and heterogenous effects')
disp(regime4');
disp('Norm error')
disp(norm(beta4-beta0)/sqrt(N*T));
subplot(224), plot(reshape(beta4(:,1),N,T)')
disp('The time-invariant effect of z')
se_z4 = sqrt(diag(Sigma_ze4));
disp([ze4 se_z4])
