% test hp_simple

N = 60;
T = 60;
p = 2;
q = 2;

regime0 = [1; fix(T/3)+1; fix(T*2/3)+1;T+1];
alpha0 = [1 2;...
         -1 -2;...
          3 4];
beta0 = kron(alpha2beta(alpha0,regime0),ones(N,1));
gamma0 = [1;-1];

f = randn(T,1); % a macro factor

x = [ones(N*T,1) kron(f,ones(N,1))];
z = randn(N*T,q);
u = randn(N,1);
y = sum(x.*beta0,2)+z*gamma0+repmat(u,T,1)+0.5*randn(N*T,1);

weight=ones(T-1,1);
XTol=1e-4;
maxIter=100;
lambda = 25;

%load simudata;

%profile on;
[tht1,gamma1]=hpbcdq(y,x,N,z,lambda,weight,XTol,maxIter);
%[tht2,gamma2]=hpbcds(y,x,N,z,lambda,weight,XTol,maxIter);
%profile viewer;

theta = reshape(tht1(:,2),N,T)';
figure(1),plot(cumsum(theta));
%disp(norm(tht1-tht2))
%disp([gamma0 gamma1])
