/*********************************************************************
 * hpbcd_C.c
 * This program implements the BCD (Block-Coordinate Descent) algorithm of 
 * PLS estimation of a heterogenous panel data model.
 * tht = mhpbcd(y,x,lambda,weight,XTol,maxIter);
 *  Output: 
 *      tht: lhs variable, a p-by-NT matrix
 *  Inputs:
 *		 y: rhs variable, a NT-by-1 vector
 *      x: rhs variables, an NT-by-p matrix
 *		 N: rhs variable, an integer
 *      lambda: tuning parameter, scalar
 *      XTol: error tolerance, scalar
 *      maxIter: max num of iterations, scalar integer
 *  Subroutines needed:
 *      useful.c useful.h
 *  To compile mex program, enter the following statement in Maltab:
 *      >> mex hpbcd_C.c useful.c
 *
 *  Junhui Qian
 *  Shanghai Jiao Tong University
 *  Jan, 2018
 *  junhuiq@gmail.com
 *
 ********************************************************************/
#include <matrix.h>
#include <mex.h>   
#include <math.h>
#include "useful.h"

static float maxarg1,maxarg2;
#define FMAX(a,b) (maxarg1=(a),maxarg2=(b),(maxarg1) > (maxarg2) ?\
        (maxarg1) : (maxarg2))
#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))

#define GOLD 1.618034
#define GLIMIT 100.0
#define TINY 1.0e-20
#define SHFT(a,b,c,d) (a)=(b);(b)=(c);(c)=(d);

void mnbrak(double *ax, double *bx, double *cx, double *fa, double *fb, double *fc, const double *R, const int N, const int p, const double lam, const double *g,
	double (*func)(double,const double*, const int, const int, const double, const double*))
{
	double ulim,u,r,q,fu,dum;

	*fa=(*func)(*ax,R,N,p,lam,g);
	*fb=(*func)(*bx,R,N,p,lam,g);
	if (*fb > *fa) {
		SHFT(dum,*ax,*bx,dum)
		SHFT(dum,*fb,*fa,dum)
	}
	*cx=(*bx)+GOLD*(*bx-*ax);
	*fc=(*func)(*cx,R,N,p,lam,g);
	while (*fb > *fc) {
		r=(*bx-*ax)*(*fb-*fc);
		q=(*bx-*cx)*(*fb-*fa);
		u=(*bx)-((*bx-*cx)*q-(*bx-*ax)*r)/
			(2.0*SIGN(FMAX(fabs(q-r),TINY),q-r));
		ulim=(*bx)+GLIMIT*(*cx-*bx);
		if ((*bx-u)*(u-*cx) > 0.0) {
			fu=(*func)(u,R,N,p,lam,g);
			if (fu < *fc) {
				*ax=(*bx);
				*bx=u;
				*fa=(*fb);
				*fb=fu;
				return;
			} else if (fu > *fb) {
				*cx=u;
				*fc=fu;
				return;
			}
			u=(*cx)+GOLD*(*cx-*bx);
			fu=(*func)(u,R,N,p,lam,g);
		} else if ((*cx-u)*(u-ulim) > 0.0) {
			fu=(*func)(u,R,N,p,lam,g);
			if (fu < *fc) {
				SHFT(*bx,*cx,u,*cx+GOLD*(*cx-*bx))
				SHFT(*fb,*fc,fu,(*func)(u,R,N,p,lam,g))
			}
		} else if ((u-ulim)*(ulim-*cx) >= 0.0) {
			u=ulim;
			fu=(*func)(u,R,N,p,lam,g);
		} else {
			u=(*cx)+GOLD*(*cx-*bx);
			fu=(*func)(u,R,N,p,lam,g);
		}
		SHFT(*ax,*bx,*cx,u)
		SHFT(*fa,*fb,*fc,fu)
	}
}
#undef GOLD
#undef GLIMIT
#undef TINY
#undef SHFT

#define ITMAX 400
#define CGOLD 0.3819660
#define ZEPS 1.0e-10
#define SHFT(a,b,c,d) (a)=(b);(b)=(c);(c)=(d);

int brent(double ax, double bx, double cx, const double *R, const int N, const int p1, const double lam, const double *g, double (*f)(double,const double*, const int, const int, const double, const double*), double tol,
	double *xmin)
{
	int iter;
	double a,b,d,etemp,fu,fv,fw,fx,p,q,r,tol1,tol2,u,v,w,x,xm;
	double e=0.0;

	a=(ax < cx ? ax : cx);
	b=(ax > cx ? ax : cx);
	x=w=v=bx;
	fw=fv=fx=(*f)(x,R,N,p1,lam,g);
	for (iter=1;iter<=ITMAX;iter++) {
		xm=0.5*(a+b);
		tol2=2.0*(tol1=tol*fabs(x)+ZEPS);
		if (fabs(x-xm) <= (tol2-0.5*(b-a))) {
			*xmin=x;
			return 1;
		}
		if (fabs(e) > tol1) {
			r=(x-w)*(fx-fv);
			q=(x-v)*(fx-fw);
			p=(x-v)*q-(x-w)*r;
			q=2.0*(q-r);
			if (q > 0.0) p = -p;
			q=fabs(q);
			etemp=e;
			e=d;
			if (fabs(p) >= fabs(0.5*q*etemp) || p <= q*(a-x) || p >= q*(b-x))
				d=CGOLD*(e=(x >= xm ? a-x : b-x));
			else {
				d=p/q;
				u=x+d;
				if (u-a < tol2 || b-u < tol2)
					d=SIGN(tol1,xm-x);
			}
		} else {
			d=CGOLD*(e=(x >= xm ? a-x : b-x));
		}
		u=(fabs(d) >= tol1 ? x+d : x+SIGN(tol1,d));
		fu=(*f)(u,R,N,p1,lam,g);
		if (fu <= fx) {
			if (u >= x) a=x; else b=x;
			SHFT(v,w,x,u)
			SHFT(fv,fw,fx,fu)
		} else {
			if (u < x) a=u; else b=u;
			if (fu <= fw || w == x) {
				v=w;
				w=u;
				fv=fw;
				fw=fu;
			} else if (fu <= fv || v == x || v == w) {
				v=u;
				fv=fu;
			}
		}
	}
//	nrerror("Too many iterations in brent");
	*xmin=x;
	return 0;
}
#undef ITMAX
#undef CGOLD
#undef ZEPS
#undef SHFT


double func(double gam, const double *R, int N, int p, const double lam, const double *g){
    int i,j;
    double *A, *A1, *g1, *v1,sum;
    
	if(gam<0)
		return 1e+6;

	A   = (double *)malloc(N*N*p*p*sizeof(double));
	g1   = (double *)malloc(N*p*sizeof(double));
	A1   = (double *)malloc(p*p*sizeof(double));
	v1   = (double *)malloc(p*sizeof(double));

    for(i=0;i<N*N*p*p;i++)
        A[i] = gam*R[i];
    for(i=0;i<N*p;i++)
        A[i*N*p+i] = A[i*N*p+i]+lam*lam/2;
    for(i=0;i<N*p;i++)
        g1[i] = g[i];

    for(i=0;i<N;i++){
        getblock(A,N*p,N*p,i*p,i*p,p,p,A1);
        getblock(g1,1,N*p,0,i*p,1,p,v1);
        gaussj(A1,p,v1,1);
        for(j=0;j<p;j++)
            g1[i*p+j]=v1[j];
    }
    //gaussj(A, p, q, 1);
    
    sum=0;
    for(i=0;i<N*p;i++)
        sum = sum + g[i]*g1[i];
    free(A);
    free(g1);
    free(A1);
    free(v1);
    return gam*(1-0.5*sum);
}

void whpbcdq(double *y,double *x,double *z, int N,int T,int p,int q,double *lambda,double *weight,double *XTol,double *maxIter,double *b,double *gamma)
{
    double *xx,*xy,*xz,*zy,*zz,*S_zy,*S_zz,*S_xx,*S_xy,*S_xz;
    double *A1,*A2,*A3,*A4,*A5,*r1,*r2;
    double *Rpp1,*Rpp2,*Rp1,*Rp2,*Rpq1,*Rpq2,*Rq,*Rqq; 
    double *err,*b0,*g,*g1,*v1,*v2,*v3,*v4,*beta,*Rg,*gamma0;
    double ax,bx,cx,fa,fb,fc,xmin,errn,dTmp,lam,dTmp1;
    int i,j,k,t,ii,tt,exitflag,jj;
    
    ax = 1e-16; bx = 1e+6;

 	xx      = (double *)malloc(T*N*p*p*sizeof(double));
	xy      = (double *)malloc(T*N*p*sizeof(double));
	S_xx    = (double *)malloc(T*N*p*p*sizeof(double));
	S_xy    = (double *)malloc(T*N*p*sizeof(double));
    
	A1   = (double *)malloc(p*p*sizeof(double));
	A5   = (double *)malloc(p*p*sizeof(double));
	r1   = (double *)malloc(N*p*sizeof(double));

	Rpp1 = (double *)malloc(T*p*p*N*sizeof(double));
	Rpp2 = (double *)malloc(T*p*p*N*sizeof(double));
	Rp1  = (double *)malloc(T*p*N*sizeof(double));
	Rp2  = (double *)malloc(T*p*N*sizeof(double));
    
	err  = (double *)malloc((T*p*N+q)*sizeof(double));
  	b0   = (double *)malloc(p*N*T*sizeof(double));
  	g    = (double *)malloc(p*N*sizeof(double));
  	g1   = (double *)malloc(p*N*sizeof(double));
  	v1   = (double *)malloc(p*sizeof(double));
  	v2   = (double *)malloc(p*sizeof(double));
  	beta = (double *)malloc(p*N*sizeof(double));
  	Rg   = (double *)malloc(N*p*p*N*sizeof(double));

    if(q>0){
        S_xz = (double *)malloc(T*N*p*q*sizeof(double));
        xz   = (double *)malloc(T*N*p*q*sizeof(double));
        zy   = (double *)malloc(T*N*q*sizeof(double));
        zz   = (double *)malloc(T*N*q*q*sizeof(double));
        S_zy = (double *)malloc(q*sizeof(double));
        S_zz = (double *)malloc(q*q*sizeof(double));
        A2   = (double *)malloc(p*q*sizeof(double));
        A3   = (double *)malloc(q*q*sizeof(double));
        A4   = (double *)malloc(p*q*sizeof(double));
        r2   = (double *)malloc(q*sizeof(double));
        Rpq1 = (double *)malloc(T*p*q*N*sizeof(double));
        Rpq2 = (double *)malloc(T*p*q*N*sizeof(double));
        Rq   = (double *)malloc(q*N*sizeof(double));
        Rqq  = (double *)malloc(q*q*N*sizeof(double));
        v3   = (double *)malloc(q*sizeof(double));
        v4   = (double *)malloc(q*sizeof(double));
        gamma0= (double *)malloc(q*sizeof(double));
    }
    
    for(j=0;j<T;j++){
		for(i=0;i<N;i++){
			getblock(x,T*N,p,j*N+i,0,1,p,v1);
			mtimes(v1,p,1,v1,p,A1);
			putblock(xx,T,N*p*p,j,i*p*p,1,p*p,A1);
			for(k=0;k<p;k++)
				v2[k]=v1[k]*y[j*N+i];
			putblock(xy,T,N*p,j,i*p,1,p,v2);
            
            if (q>0){
				getblock(z,T*N,q,j*N+i,0,1,q,v3);
                mtimes(v1,p,1,v3,q,A2);
    			putblock(xz,T,N*p*q,j,i*p*q,1,p*q,A2);
                mtimes(v3,q,1,v3,q,A3);
    			putblock(zz,T,N*q*q,j,i*q*q,1,q*q,A3);
    			for(k=0;k<q;k++)
        			v4[k]=v3[k]*y[j*N+i];
    			putblock(zy,T,N*q,j,i*q,1,q,v4);
            }
		}
	}
    
    invshift(xx,T,N*p*p,Rpp1);
    cumsum(Rpp1,T,N*p*p,Rpp2);
    invshift(Rpp2,T,N*p*p,S_xx);

    invshift(xy,T,N*p,Rp1);
    cumsum(Rp1,T,N*p,Rp2);
    invshift(Rp2,T,N*p,S_xy);
    
//    getblock(S_xy,T,p*N,T-2,0,1,p,v1);
//        mexPrintf("%f,%f,%f,%f\n",S_xx[0],S_xx[1],S_xx[2],S_xx[3]);


    if (q>0){
        invshift(xz,T,N*p*q,Rpq1);
        cumsum(Rpq1,T,N*p*q,Rpq2);
        invshift(Rpq2,T,N*p*q,S_xz);
        
        summ(zy,T,N*q,1,Rq);
        summ(Rq,q,N,2,S_zy);
        
        summ(zz,T,N*q*q,1,Rqq);
        summ(Rqq,q*q,N,2,S_zz);
    }

//        mexPrintf("%f,%f\n",S_zy[0],S_zy[1]);
//        mexPrintf("%f,%f,%f,%f\n",S_zz[0],S_zz[1],S_zz[2],S_zz[3]);

    fillzero(b0,T*p*N);
    if(q>0){
        fillzero(gamma0,q);
    }
    errn=1e+10; 
    i = 0;
    while(errn>*XTol && i<*maxIter){
        i=i+1;
        for(t=1;t<=T;t++){
			if(t==1){
				getblock(S_xy,T,p*N,0,0,1,N*p,r1);
				for(tt=2;tt<=T;tt++){
					fillzero(beta,N*p);
					for(j=1;j<tt;j++){
						getblock(b0,1,T*p*N,0,j*N*p,1,p*N,g1);
						for(k=0;k<N*p;k++)
							beta[k]=beta[k]+g1[k];
					}
					for(ii=0;ii<N;ii++){
						getblock(xx,T,p*p*N,tt-1,ii*p*p,1,p*p,A1);
						getblock(beta,1,N*p,0,ii*p,1,p,v1);
						mtimes(A1,p,p,v1,1,v2);
						for(k=0;k<p;k++) 
							r1[ii*p+k] = r1[ii*p+k] - v2[k];
					}
				}
                if(q>0){
    				getblock(S_zy,1,q,0,0,1,q,r2);
					for(ii=0;ii<N;ii++){
						getblock(S_xz,T,p*q*N,0,ii*p*q,1,p*q,A2);
                        mtrans(A2,p,q,A4);
						getblock(b0,1,T*N*p,0,ii*p,1,p,v1);
						mtimes(A4,q,p,v1,1,v3);
						for(k=0;k<q;k++) 
							r2[k] = r2[k] - v3[k];
					}
    				for(tt=2;tt<=T;tt++){
        				fillzero(beta,N*p);
            			for(j=1;j<tt;j++){
                			getblock(b0,1,T*p*N,0,j*N*p,1,p*N,g1);
                    		for(k=0;k<N*p;k++)
                        		beta[k]=beta[k]+g1[k];
                        }
    					for(ii=0;ii<N;ii++){
        					getblock(xz,T,p*q*N,tt-1,ii*p*q,1,p*q,A2);
            				getblock(beta,1,N*p,0,ii*p,1,p,v1);
                            mtrans(A2,p,q,A4);
                			mtimes(A4,q,p,v1,1,v3);
                    		for(k=0;k<q;k++) 
                        		r2[k] = r2[k] - v3[k];
                        }
    				}
                    for(ii=0;ii<q*q;ii++)
                        A3[ii]=S_zz[ii];
                    gaussj(A3, q, r2, 1);
                    for(k=0;k<q;k++){
                        gamma[k]=r2[k];
                    }
                    for(ii=0;ii<N;ii++){
                        getblock(S_xz,T,p*q*N,0,ii*p*q,1,p*q,A2);
                        mtimes(A2,p,q,gamma,1,v1);
                        for(k=0;k<p;k++) 
							r1[ii*p+k] = r1[ii*p+k] - v1[k];
                    }
                }
				for(ii=0;ii<N;ii++){
					getblock(S_xx,T,p*p*N,0,ii*p*p,1,p*p,A1);
					getblock(r1,1,p*N,0,ii*p,1,p,v1);
					gaussj(A1, p, v1, 1);
					for(k=0;k<p;k++)
						b[ii*p+k] = v1[k];
				}
			}else{
		   /* 1<t<=T*/
               getblock(S_xy,T,p*N,t-1,0,1,N*p,g);
               fillzero(beta,N*p);
    		   for(tt=0;tt<t-1;tt++){
        		   getblock(b,1,T*p*N,0,tt*N*p,1,p*N,g1);
            	   for(k=0;k<N*p;k++)
                	   beta[k]=beta[k]+g1[k];
    		   }
        	   for(ii=0;ii<N;ii++){
				   getblock(xx,T,p*p*N,t-1,ii*p*p,1,p*p,A1);
                   getblock(beta,1,N*p,0,ii*p,1,p,v1);
                   mtimes(A1,p,p,v1,1,v2);
                   for(k=0;k<p;k++)
					   g[ii*p+k] = g[ii*p+k] - v2[k];
    		   }

        	   if(t<T){
                   for(tt=t;tt<T;tt++){
					   fillzero(beta,N*p);
    				   for(j=0;j<t-1;j++){
						   getblock(b,1,T*p*N,0,j*N*p,1,p*N,g1);
            			   for(k=0;k<N*p;k++)
							   beta[k]=beta[k]+g1[k];
                    	}
                        for(j=t;j<=tt;j++){
							getblock(b0,1,T*p*N,0,j*N*p,1,p*N,g1);
                            for(k=0;k<N*p;k++)
                                beta[k]=beta[k]+g1[k];
    					}
        				for(ii=0;ii<N;ii++){
            			    getblock(xx,T,p*p*N,tt,ii*p*p,1,p*p,A1);
                			getblock(beta,1,p*N,0,ii*p,1,p,v1);
                    		mtimes(A1,p,p,v1,1,v2);
                        	for(k=0;k<p;k++)
                            	g[ii*p+k] = g[ii*p+k] - v2[k];
    					}
        			}
               }
               if(q>0){
                   for(ii=0;ii<N;ii++){
                       getblock(S_xz,T,p*q*N,t-1,ii*p*q,1,p*q,A2);
                       mtimes(A2,p,q,gamma,1,v1);
                       for(k=0;k<p;k++)
                           g[ii*p+k] = g[ii*p+k] - v1[k];
                   }
               }
        	   dTmp = norm2(g,N*p);
			   lam = (*lambda)*weight[t-2];
               if(dTmp <= lam){
                   for(k=0;k<N*p;k++)
                       b[(t-1)*N*p+k]=0;
               }else{
                   for(k=0;k<N*p;k++)
                       g[k]=-g[k];
                   fillzero(Rg,N*N*p*p);
                   for(ii=0;ii<N;ii++){
                       getblock(S_xx,T,p*p*N,t-1,ii*p*p,1,p*p,A1);
                       putblock(Rg,N*p,N*p,ii*p,ii*p,p,p,A1);
                    }
				   mnbrak(&ax,&bx,&cx,&fa,&fb,&fc,Rg,N,p,lam,g,func);
                   exitflag = brent(ax,bx,cx,Rg,N,p,lam,g,func,*XTol,&xmin);
                   if(exitflag==1){
					   for(k=0;k<p*p*N*N;k++)
						   Rg[k] = xmin*Rg[k];
					   for(k=0;k<p*N;k++)
						   Rg[k*p*N+k] = Rg[k*p*N+k]+lam*lam/2;
                       for(ii=0;ii<N;ii++){
                           getblock(Rg,N*p,N*p,ii*p,ii*p,p,p,A1);
                           getblock(g,1,N*p,0,ii*p,1,p,v1);
                           gaussj(A1,p,v1,1);
                           for(jj=0;jj<p;jj++)
                               b[(t-1)*N*p+ii*p+jj]=-xmin*v1[jj];
                       }
                       
/*                       gaussj(Rg,p*N,g,1);
                       for(k=0;k<N*p;k++)
						   b[(t-1)*N*p+k]=-xmin*g[k];*/
				   }else{
					   for(k=0;k<N*p;k++)
						   b[(t-1)*N*p+k]=0;
                       
				   }
               }
           }
        }
//               if(i==1){
//                   for(ii=0;ii<N*T*p;ii++)
//                       mexPrintf("%f ",b[ii]);
//                   mexPrintf("\n");
//               }
		for(k=0;k<p*N*T;k++)
			err[k]=b[k]-b0[k];
        if(q>0){
            for(k=0;k<q;k++)
                err[p*N*T+k]=gamma[k]-gamma0[k];
        }
        errn = norm2(err,T*p*N+q);
		for(k=0;k<p*N*T;k++)
			b0[k]=b[k];
        for(k=0;k<q;k++)
            gamma0[k]=gamma[k];
    }
    
    free(xx);
    free(xy);
    free(S_xx);
    free(S_xy);
    free(A1);
    free(A5);
    free(r1);
	
    free(Rpp1);
    free(Rpp2);
    free(Rp1);
    free(Rp2);

    free(err);
    free(b0);
    free(g);
    free(g1);
    free(v1);
    free(v2);
    free(Rg);
    free(beta);
    if(q>0){
        free(S_xz);
        free(xz);
        free(zy);
        free(zz);
        free(S_zy);
        free(S_zz);
        free(A2);
        free(A3);
        free(A4);
        free(r2);
        free(Rpq1);
        free(Rpq2);
        free(Rq);
        free(Rqq);
        free(v3);
    	free(v4);
    }
}
        
void mexFunction(mwSize nlhs, mxArray *plhs[], mwSize nrhs, const mxArray *prhs[])
{
    #define b_out       plhs[0]
    #define g_out       plhs[1]
    #define y_in        prhs[0]
    #define x_in        prhs[1]
    #define N_in        prhs[2]
    #define z_in        prhs[3]
    #define lambda_in   prhs[4]
    #define weight_in   prhs[5]
    #define XTol_in     prhs[6]
    #define maxIter_in  prhs[7]
    
//declare variables
    const mwSize *dims;
    double *y,*x,*z,*lambda,*weight,*XTol,*maxIter,*b,*Np,*gamma; // inputs and outputs
    int n,p,q,N,T;

    if (nrhs < 8) {
        mexErrMsgIdAndTxt( "MATLAB:mxsetdimensions:minrhs",
                "At least 6 input arguments required.");
    }
    if(nlhs > 2){
        mexErrMsgIdAndTxt( "MATLAB:mxsetdimensions:maxlhs",
                "Too many output arguments.");
    }

//figure out dimensions
    dims = mxGetDimensions(x_in);
    n = (mwSize)dims[0]; p = (mwSize)dims[1];
    dims = mxGetDimensions(z_in);
    q = (mwSize)dims[1];
    //mexPrintf("Hello,N=%d, T=%d, p=%d\n",N,T,p);

    
//associate pointers
    y       = mxGetPr(y_in);
    x       = mxGetPr(x_in);
    z       = mxGetPr(z_in);
	Np      = mxGetPr(N_in);
    lambda  = mxGetPr(lambda_in);
    weight  = mxGetPr(weight_in);
    XTol    = mxGetPr(XTol_in);
    maxIter = mxGetPr(maxIter_in);

	N = (*Np);
    T = n/N; 

//associate outputs
    b_out = mxCreateDoubleMatrix(p,N*T,mxREAL);
    g_out = mxCreateDoubleMatrix(q,1,mxREAL);
    b = mxGetPr(b_out);
    gamma = mxGetPr(g_out);
    whpbcdq(y,x,z,N,T,p,q,lambda,weight,XTol,maxIter,b,gamma);

    return;
}
