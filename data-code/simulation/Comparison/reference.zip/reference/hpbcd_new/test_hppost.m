%test hpbcd.m

N = 20;
T = 20;
p = 2;
beta0 = kron([ones(T/2,1);-ones(T/2,1)],ones(N,p));
X = randn(N*T,p);
u = randn(N,1);
gamma = randn(T,1);
Y = sum(X.*beta0,2)+repmat(u,T,1)+0.5*randn(N*T,1);
Y1 = sum(X.*beta0,2)+repmat(u,T,1)+kron(gamma,ones(N,1))+0.5*randn(N*T,1);
regime = [1 T/2+1 T+1]';
m = length(regime)-2;
%a1 = hppostfd(Y,X,regime);
Z = repmat(eye(N),T,1); % one-way fixed-effect model
Z1 = [repmat(eye(N),T,1) kron(eye(T),ones(N,1))]; % two-way fixed-effect model
[alpha,Sigma,mu,Smu,ssr,s2,beta,residual] = hppost(Y,X,Z,regime);
[alpha1,Sigma1,fe,Sfe,ssr1,s21,beta1,residual1] = hppost(Y1,X,Z1(:,1:N+T-1),regime);

a = reshape(alpha,p,N*(m+1))';
%a1 = reshape(a1,p,N*(m+1))';


se = sqrt(diag(Sigma));
se = reshape(se,p,N*(m+1))';
tstat = a./se;
dof = N*(T-1)-N*p*(m+1);
pv = 2*(1-tcdf(abs(tstat),dof));

%disp([a se tstat pv])
disp('Norm error')
disp(norm(beta-beta0)/sqrt(N*T));

figure(1), 
subplot(211), plot(reshape(beta(:,1),N,T)'), title('Heterogeneous coefficients')
subplot(212), plot(reshape(beta1(:,1),N,T)'), title('Heterogeneous coefficients')

figure(2), 
subplot(211), plot(u,mu,'.'), xlabel('True individual effects'), ylabel('Estimated individual effects')
subplot(223), plot(u,mu1(1:N),'.'), xlabel('True individual effects'), ylabel('Estimated individual effects')
subplot(224), plot(gamma(1:T-1),mu1(N+1:N+T-1),'.'), xlabel('True time effects'), ylabel('Estimated time effects')

figure(3), 
subplot(211),plot(reshape(residual,N,T)'), title('Error term')
subplot(212),plot(reshape(residual1,N,T)'), title('Error term')
