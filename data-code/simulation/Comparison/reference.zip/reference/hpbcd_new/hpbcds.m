function [theta,gamma] = hpbcds(y,x,N,z,lambda,weight,XTol,maxIter)
% The block coordinated descent algorithm for heterogenous panel data
% model��y_it = x_it'*beta_it + z_it'*gamma + u_it
% Inputs:
%   y = [y_1;y_2;...;y_T], where y_t = [y_1t;y_2t;...,y_Nt];
%   x = [x_1;x_2;...;x_T], where x_t = [x_1t;x_2t;...,x_Nt]; a NT-by-p matrix
%   z = [z_1;z_2;...;z_T], where z_t = [z_1t;z_2t;...,z_Nt]; a NT-by-q matrix
%   N:    number of individuals
%   lambda: tuning parameter
%   XTol: Tolerance of error (default: 1e-4)
%   maxIter: max number of iterations (default: 400)
% Output:
%   theta: NT-by p matrix of theta, theta_1 = beta_1, theta_2 =
%           beta_2-beta_1..., where beta_t is Np-by-1 vector.
%   gamma: q-by-1 vector.
%
[n,p] = size(x);
T = n/N;

if nargin<4 || isempty(z)
    z=[];
end

if nargin<6 || isempty(weight)
    weight = ones(n-1,1); 
end

if nargin<7 || isempty(XTol)
    XTol = 1e-4; 
end

if nargin<8 || isempty(maxIter)
    maxIter = 400;
end

q = size(z,2);

xx = zeros(N*T,p*p);
for t=1:T
    for i=1:N
        xx((t-1)*N+i,:)=reshape(x((t-1)*N+i,:)'*x((t-1)*N+i,:),1,p*p);
    end
end
xy = zeros(N*T,p);
for t=1:T
    for i=1:N
        xy((t-1)*N+i,:)=x((t-1)*N+i,:)*y((t-1)*N+i);
    end
end

if q>0
    zz = zeros(N*T,q*q);
    xz = zeros(N*T,p*q);
    yz = zeros(N*T,q);
    for t=1:T
        for i=1:N
            xz((t-1)*N+i,:)=reshape(x((t-1)*N+i,:)'*z((t-1)*N+i,:),1,p*q);
            zz((t-1)*N+i,:)=reshape(z((t-1)*N+i,:)'*z((t-1)*N+i,:),1,q*q);
            yz((t-1)*N+i,:)=z((t-1)*N+i,:)*y((t-1)*N+i);
        end
    end
    S_zy = zeros(q,1);
    S_zz = zeros(q*q,1);
    for t=1:T
        S_zy = S_zy + sum(yz((t-1)*N+1:t*N,:),1)';
        S_zz = S_zz + sum(zz((t-1)*N+1:t*N,:),1)';
    end
    S_xz = zeros(N*T,p*q);
    for t=1:T
        S1 = zeros(N,p*q);
        for tt = 1:t
            S1 = S1 + xz((T-tt)*N+1:(T-tt+1)*N,:);
        end
        S_xz((T-t)*N+1:(T-t+1)*N,:) = S1;
    end
end

S_xx = zeros(N*T,p*p);
S_xy = zeros(N*T,p);
for t=1:T
    S1 = zeros(N,p*p);
    S2 = zeros(N,p);
    for tt = 1:t
        S1 = S1 + xx((T-tt)*N+1:(T-tt+1)*N,:);
        S2 = S2 + xy((T-tt)*N+1:(T-tt+1)*N,:);       
    end
    S_xx((T-t)*N+1:(T-t+1)*N,:) = S1;
    S_xy((T-t)*N+1:(T-t+1)*N,:) = S2;
end

d0 = zeros(T*N*p+q,1);
d1 = zeros(T*N*p+q,1);

e = 1e10;
i = 0;
while e>XTol && i<maxIter
    i = i + 1;
    for t = 1:T
        if t == 1
            r1 = reshape(S_xy(1:N,:)',N*p,1);
            for tt=2:T
                beta = zeros(N*p,1);
                for ss=2:tt
                    beta = beta + d0((ss-1)*N*p+1:ss*N*p);
                end
                for ii = 1:N
                    r1((ii-1)*p+1:ii*p) = r1((ii-1)*p+1:ii*p) - reshape(xx((tt-1)*N+ii,:),p,p)*beta((ii-1)*p+1:ii*p);
                end
            end

            if q>0
                r2 = S_zy;
                for ii=1:N
                    r2 = r2 - reshape(S_xz(ii,:),p,q)'*d0((ii-1)*p+1:ii*p);
                end
                for tt = 2:T
                    beta = zeros(N*p,1);
                    for ss=2:tt
                        beta = beta + d0((ss-1)*N*p+1:ss*N*p);
                    end
                    for ii = 1:N
                        r2 = r2 - reshape(xz((tt-1)*N+ii,:),p,q)'*beta((ii-1)*p+1:ii*p);
                    end
                end 
                gamma = reshape(S_zz,q,q)\r2;
                for ii=1:N
                    r1((ii-1)*p+1:ii*p) = r1((ii-1)*p+1:ii*p)-reshape(S_xz(ii,:),p,q)*gamma;
                end
                d1(N*p+1:N*p+q) = gamma;
            end            
            
            for ii=1:N
                d1((ii-1)*p+1:ii*p) = reshape(S_xx(ii,:),p,p)\r1((ii-1)*p+1:ii*p);
            end
            
        else 
            g = reshape(S_xy((t-1)*N+1:t*N,:)',N*p,1);
            beta = zeros(N*p,1);
            for ss = 1:t-1
                beta = beta+d1((ss-1)*N*p+1:ss*N*p);
            end 
            for ii = 1:N
                g((ii-1)*p+1:ii*p) = g((ii-1)*p+1:ii*p) - reshape(xx((t-1)*N+ii,:),p,p)'*beta((ii-1)*p+1:ii*p) ;
            end
           
            if t < T
                for tt = t+1:T
                    beta = zeros(N*p,1);
                    for ss = 1:t-1
                        beta = beta+d1((ss-1)*N*p+1:ss*N*p);
                    end
                    for ss = t+1:tt
                        beta = beta+d0((ss-1)*N*p+1:ss*N*p);
                    end
                    for ii = 1:N
                        g((ii-1)*p+1:ii*p) = g((ii-1)*p+1:ii*p) - reshape(xx((tt-1)*N+ii,:),p,p)*beta((ii-1)*p+1:ii*p);
                    end
                end
            end 
            if q>0
                for ii=1:N
                    g((ii-1)*p+1:ii*p) = g((ii-1)*p+1:ii*p)-reshape(S_xz((t-1)*N+ii,:),p,q)*gamma;
                end
            end
            if norm(g)<=lambda*weight(t-1)
                d1((t-1)*N*p+1:t*N*p) = 0;
            else
                g = -g;
                R = zeros(N*p,N*p);
                for ii = 1:N
                    R((ii-1)*p+1:ii*p,(ii-1)*p+1:ii*p) = reshape(S_xx((t-1)*N+ii,:),p,p);
                end
%                [gam,fval,exitflag] = fminsearch(@myfun2,1/N,[],R,lambda*weight(t-1),g);
%                [gam,fval,exitflag] = fminbnd(@myfun2,0,10,[],R((t-1)*p+1:t*p,(t-1)*p+1:t*p),lambda,g);
                [gam,fval,exitflag] = fzero(@myfun,[1e-16;1e6],[],R,lambda*weight(t-1),g);
                if exitflag==1
                    tmp=(gam*R + (lambda*weight(t-1))^2/2*eye(N*p))\g;
                    d1((t-1)*N*p+1:t*N*p) = -gam*tmp;
                else
                    disp('Line search failed');
                    theta = reshape(d1(1:N*T*p),p,N*T)';
                    return;
                end
            end
        end
    end
    e = norm(d1-d0);
    d0 = d1;
%    disp([i e])
end
theta = reshape(d1(1:N*T*p),p,N*T)';

function y = myfun(gam,R,lam,g)
p = length(g);
tmp=lam/2 * ((gam*R+lam^2/2*eye(p))\g);
y =  sum(tmp.^2) - 1;

function y = myfun2(gam,R,lam,g)
if gam<0
    y=1e10;
    return;
end
p = length(g);
y = gam*(1-1/2*g'*((gam*R+lam^2/2*eye(p))\g));


