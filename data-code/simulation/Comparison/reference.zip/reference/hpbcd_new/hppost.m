function [alpha,Sigma,ze,Sigmaze,ssr,s2,beta,residual] = hppost(y,x,z,regime)
% y_it = mu_i + x_it'beta_it + u_it, i=1,...,N, t=1,...,T
% x = [x1;x2;...;xT]; NT by p
% regime = [1 T1+1 T2+1 ... Tm+1 T+1]';
% alpha: (m+1)N-by-p
% ze: the effect of z
% This post-Lasso estimation program is based on LSDV, treating mu_i as coefficients on dummies.

[n,p] = size(x);

m = length(regime)-2;
T = regime(m+2)-1;
N = n/T;

Phi = zeros(n,p*N*(m+1));
for j=1:m+1
    for t=regime(j):regime(j+1)-1
        xt = zeros(p*N,N);
        for i=1:N
            xt((i-1)*p+1:i*p,i)= x((t-1)*N+i,:)'; % N by p
        end
        Phi((t-1)*N+1:t*N,(j-1)*p*N+1:j*p*N)=xt';
    end
end

Pz = z*((z'*z)\z');
Mz = eye(n)-Pz;
alpha = (Phi'*Mz*Phi)\(Phi'*Mz*y);
Mp = eye(n)-Phi*((Phi'*Phi)\Phi');
ze = (z'*Mp*z)\(z'*Mp*y);

residual = y-Phi*alpha-z*ze;
ssr = residual'*residual;
s2 = ssr/(n-N*(m+1)*p);
Sigma = s2*((Phi'*Mz*Phi)\eye(N*(m+1)*p));
Sigmaze  = s2*((z'*Mp*z)\eye(size(z,2)));
%theta = [Phi Z]\y;
%alpha = theta(1:p*N*(m+1));
%mu = theta(p*N*(m+1)+1:p*N*(m+1)+N);

a = reshape(alpha,p,N*(m+1))';
beta = zeros(n,p);
for j = 1:m+1
    for t = regime(j):regime(j+1)-1
        beta((t-1)*N+1:t*N,:) = a((j-1)*N+1:j*N,:);
    end
end

