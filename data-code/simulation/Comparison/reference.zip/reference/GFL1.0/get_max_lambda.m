function L = get_max_lambda(y,x,z)
if nargin < 3 
    z=[];
end
[n,p] = size(x);
q = size(z,2);
if q==0
    M = eye(n);
else
    M = eye(n)-z*inv(z'*z)*(z');
end
yt = M*y;
xt = x;
b0 = (xt'*xt)\xt'*yt;
u = 2*cumsum(repmat((yt - xt*b0),1,p).*xt);
L = max((sum(u.^2,2)).^(1/2));
