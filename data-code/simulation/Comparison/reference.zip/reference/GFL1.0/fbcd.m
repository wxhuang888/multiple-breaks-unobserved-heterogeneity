function [theta,gamma] = fbcd(y,x,z,lambda,weight,XTol,maxIter)
% The block coordinated descent algorithm
% y = x_t' * beta_t + z_t' * gamma + u_t
% Input: 
%   y: n-by-1 vector, the dependent variable
%   x: n-by-p matrix, the independent variables that may have time-varying
%           effects on y
%   z: n-by-q matrix, the independent variables that have constant effects
%   lambda: the penalty term
%   weight: (optional) an (n-1)-by-1 vector of positive weights.
%   XTol: (optional) a small positive number, error tolerance parameter 
%   maxIter: (optional) an integer, the max number of iterations
% Output:
%   theta: n-by-p matrix, theta(1)=beta(1), theta(t)=beta(t)-beta(t-1) for
%           t>1
%   gamma: q-by-1 vector, estimated gamma.
%   Junhui Qian
%   junhuiq@gmail.com
%   2018.11.20

[n,p] = size(x);
q = size(z,2);

if nargin<5 || isempty(weight)
    weight = ones(n-1,1); 
end

if nargin<6 || isempty(XTol)
    XTol = 1e-4; 
end

if nargin<7 || isempty(maxIter)
    maxIter = 400;
end


Sxx = zeros(n,p*p);
Sxy = zeros(n,p);
for i=1:n
    Sxx(i,:) = reshape(x(i,:)'*x(i,:),1,p*p);
    Sxy(i,:) = x(i,:)'*y(i);
end
Sxx = cumsum(Sxx(n:-1:1,:));
Sxx = Sxx(n:-1:1,:);
Sxy = cumsum(Sxy(n:-1:1,:));
Sxy = Sxy(n:-1:1,:);

if q>0
    Sxz = zeros(n,p*q);
    for i=1:n
        Sxz(i,:) = reshape(x(i,:)'*z(i,:),1,p*q);
    end
    Sxz = cumsum(Sxz(n:-1:1,:));
    Sxz = Sxz(n:-1:1,:);
    Szz = z'*z;
end

d0 = zeros(n,p);
d0(1) = 0.01;
d1 = zeros(n,p);

e = 1e10;
i = 0;
while e>XTol && i<maxIter
    i = i+1;
    for nn = 1:n
        if nn == 1
            if q > 0
                beta = cumsum(d1);
                gamma = Szz\(z'*(y-sum(x.*beta,2)));
                s2 = z*gamma;
            else
                s2 = zeros(n,1);
            end
            beta1 = cumsum(d1(2:n,:));
            s1 = [0;sum(x(2:n,:).*beta1,2)];
            d1(1,:) = (reshape(Sxx(1,:),p,p) \ (x'*(y-s1-s2)))';
        else
            if q > 0
                beta = cumsum([d1(1:nn-1,:); d0(nn:n,:)]);
                gamma = Szz\(z'*(y-sum(x.*beta,2)));
                s3 = reshape(Sxz(nn,:),p,q)*gamma;
            else
                s3 = zeros(p,1);
            end
            s1 =  x(nn,:)'*x(nn,:)*(sum(d1(1:nn-1,:),1))';
            s2 = zeros(p,1);
            for t=nn+1:n
                s2 = s2 + x(t,:)'*(x(t,:)*(sum(d1(1:nn-1,:),1) + sum(d0(nn+1:t,:),1))');
            end
            g = -(Sxy(nn,:)'-s1-s2-s3);
            if norm(g)<=lambda*weight(nn-1)
                d1(nn,:) = 0;
            else
                R = reshape(Sxx(nn,:),p,p);
%                [gam,fval,exitflag] = fminsearch(@myfun2,1,[],R,lambda*weight(nn-1),g);
                [gam,fval,exitflag] = fminbnd(@myfun2,0,1e10,[],R,lambda*weight(nn-1),g);
%                [gam,fval,exitflag] = fzero(@myfun,0.1,[],reshape(Rn(nn,:),p,p),lambda,g(nn,:)');
                if exitflag==1
                    d1(nn,:) = -gam*((gam*R + (lambda*weight(nn-1))^2/2*eye(p))\g)';
                else
                    disp('Line search failed');
                    d1(nn,:)=zeros(1,p); 
                end
            end
        end
    end
    e = norm(reshape(d1-d0,n*p,1))/norm(reshape(d0,n*p,1));
    d0 = d1;
%    disp([i e])
end
theta = d1;
if q==0
    gamma = [];
end

function y = myfun(gam,R,lam,g)
p = length(g);
if gam<=0
    y = 1e10;
else
    tmp=lam/2 * (gam*R+lam^2/2*eye(p))\g;
    y =  sum(tmp.^2) - 1;
end

function y = myfun2(gam,R,lam,g)
if gam<0
    y=1e10;
    return;
end
p = length(g);
y = gam*(1-1/2*g'*((gam*R+lam^2/2*eye(p))\g));
