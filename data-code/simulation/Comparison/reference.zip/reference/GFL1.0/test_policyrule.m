load policy_rule;

n = size(num,1);

gap = num(:,3);
r = num(:,5);
pi = num(:,6);

k = 1; q = 1; T0 = 1;
T = n-max(k,q)-T0;
y = r(T0+1:T0+T);
year = num(T0+1:T0+T,1);
quarter = num(T0+1:T0+T,2);

date = cell(T,1);
for i=1:T
    date{i}=[num2str(year(i)) 'Q' num2str(quarter(i))];
end

% Backward-looking with interest rate smoothing
 x = [ones(T,1) pi(T0+1:T0+T) gap(T0+1:T0+T)];
 z = []; 
%*************************************%

%*** Forward-looking *****************%
% x = [ones(T,1) pi(T0+1+k:T0+T+k) gap(T0+1+q:T0+T+q)]; 
% z = [];
%*************************************%

% Backward-looking with interest rate smoothing
% x = [ones(T,1) pi(T0+1:T0+T) gap(T0+1:T0+T)];
% z = [r(T0:T0+T-1)];
%**************************************%

option.lambda='cv'; % 'ic' for information criterion, 'cv' for cross-validation, or a numeric. 
option.date=date;

gfl(y,x,z,option);

