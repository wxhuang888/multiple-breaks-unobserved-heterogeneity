T = 120;
regime0 = [1; T/2+1; T+1];
alpha0 = [1 1;...
        0.5 0;];
p = size(alpha0,2);
b = alpha2beta(alpha0,regime0);
x = [ones(T,1) randn(T,p-1)];
s = sum(x.*b,2);

z = [0.5*randn(T,1)+0.5*x(:,2) randn(T,1) randn(T,1)];
gamma0 = [1 0.5 1]';

p = size(x,2);
q = size(z,2);

sigma = 0.5;
y = s+z*gamma0+sigma*randn(T,1);

lambda = 10;
alpha = 1;
XTol = 1e-4;
maxIter=400;
weight = ones(T-1,1);

%disp(x'*z);

[theta1,gamma1] = mfbcd(y,x,z,lambda,weight,XTol,maxIter);
[theta2,gamma2] = fbcd(y,x,z,lambda,weight,XTol,maxIter);
%theta4 = mbcd(y,x,lambda,weight,XTol,maxIter);
plot(cumsum(theta1));
disp([norm(theta1-theta2) norm(gamma1-gamma2)]);



