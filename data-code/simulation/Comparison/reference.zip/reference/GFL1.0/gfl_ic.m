function [regime,alpha,R2,Sigma,ssr,resid,lambda,IC,K,L] = gfl_ic(y,x,z,option)
% [regime,alpha,Sigma,ssr,resid,IC,K,lambda] = gfl_ic(y,x,z,lambda)
% Estimate linear regressions with structural breaks, using group fused
% lasso (GFL) with information criterion. The model is:
%   y = x_t' * beta_t + z_t' * gamma + u_t
%
% Inputs:
%   y:      explained variable (n by 1)
%   x:      explanatory variables with time-varying effect (n by p)
%   z:      (optional) explanatory variables without time-varying effect (n by q)
%   option: (optional) some options. If the procedure does not work on some 
%               computers, set option.mex=0. 
%   
% Outputs:
%   regime: a vector of breakdates. By convention, the first element is 1
%           and the last element is n+1. The first estimated breakdate 
%           regime(2), the second is regime(3), and so on.
%   alpha:  an (n by p) matrix of estimated coefficients. Rows correspond to
%           regimes in time order
%   R2:     R-square for each regime and for the whole sampleR
%   Sigma:  an (n by p*p) matrix of estimated covariance matrices. Rows
%           correspond to regimes in time order. To get standard errors, use
%           the procedure get_se(Sigma). 
%   ssr:    a scalar, the sum of squared residuals.
%   resid:  an n-by-1 vector of residuals. 
%   lambda: a scalar, the tuning parameter that yields the smallest IC.
%   IC:     a vector of information criteria calculated in model selection
%   K:      a vector of numbers of breaks corresponding to different tuning
%           parameters in lambda
%   L:      a vector of tuning parameters considered.
%
%   To see how the procedure can be applied, run test_gfl_ic.m
%
%   Reference: Junhui Qian and Liangjun Su, 2016, Shrinkage estimation of 
%       regression models with multiple structural changes
%   Last update: Nov 26, 2018

[n,p] = size(x);

if nargin < 3 || isempty(z)
    z=[];
end

q = size(z,2);

if nargin < 4 || isempty(option)
    option.L = [];
    option.weight=ones(n-1,1);
    option.XTol=1e-6;
    option.maxIter=1000;
    option.h = 1; % smoothing parameter in finding the breaks. Smaller h yields more breaks
    option.minseg=p+q+1;
    option.mex=1; % mex implementation is much faster, but may not work on some computers, in which case set mex=0. 
end

if ~isfield(option,'date') || isempty(option.date)
    date=cell(n,1);
    for i=1:n
        date{i}=num2str(i);
    end
    option.date=date;
end
if ~isfield(option,'lambda') || isempty(option.lambda)
    option.lambda='ic';
end
if ~isfield(option,'weight') || isempty(option.weight)
    option.weight=ones(n-1,1);
end
if ~isfield(option,'XTol') || isempty(option.XTol)
    option.XTol=1e-6;
end
if ~isfield(option,'maxIter') || isempty(option.maxIter)
    option.maxIter=1000;
end
if ~isfield(option,'h') || isempty(option.h)
    option.h=1;
end
if ~isfield(option,'minseg') || isempty(option.minseg)
    option.minseg=p+q+1;
end
if ~isfield(option,'mex') || isempty(option.mex)
    option.mex=1;
end

if isempty(option.L) || ~isfield(option,'L')
    S = 20;
    lam_max = get_max_lambda(y,x,z);
    lam_min = 0.1*lam_max;
    R = log(lam_max/lam_min)/(S-1);
    L = lam_min*exp(R*(0:S-1)');
end

S = length(L);
IC = zeros(S,1);
K = zeros(S,1);
THT = zeros(n,S*p);
for i = 1:S
    if option.mex
        tht = mfbcd(y,x,z,L(i),option.weight,option.XTol,option.maxIter);
    else
        tht = fbcd(y,x,z,L(i),option.weight,option.XTol,option.maxIter);
    end
    THT(:,p*(i-1)+1:p*i) = tht;
    regime = findbreaks(tht,option.h,option.minseg);
    [tmp1,ssr] = fpostest(y,x,z,regime);
    k = length(regime)-2;
    IC(i) = log(ssr/n) + ((k+1)*p+q)/sqrt(n); 
    K(i) = k;
end
[tmp,i]=min(IC);
lambda = L(i);
theta = THT(:,p*(i-1)+1:p*i);

regime = findbreaks(theta,option.h,option.minseg);
[alpha,ssr,R2,resid,Sigma] = fpostest(y,x,z,regime);







