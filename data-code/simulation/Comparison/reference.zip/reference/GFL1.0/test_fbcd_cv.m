% Estimate the following model:
% y = x_t' * beta_t + z_t' * gamma + u_t,
%   where beta_t has 2 breaks (3 regimes).
%

% 1. Data Generation
T = 120;
regime0 = [1; T/2+1; T+1];
alpha0 = [1 0.5;...
        0.5 1;];
p = size(alpha0,2);
b = alpha2beta(alpha0,regime0);
x = [ones(T,1) randn(T,p-1)];
s = sum(x.*b,2);

z = [0.5*randn(T,1)+0.5*x(:,2) randn(T,1) randn(T,1)];
gamma0 = 0*[1 0.5 1]';

sigma = 0.5;
y = s+z*gamma0+sigma*randn(T,1);

% 2. Model estimation
z=[];
p = size(x,2);
q = size(z,2);
lam_max = get_max_lambda(y,x,[]);
L = [0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8]*lam_max;
[lambda,cv]=fbcd_cv(y,x,z,L);
[theta1,gamma1] = mfbcd(y,x,z,lambda,ones(T-1,1),1e-4,400);
regime = findbreaks(theta1);
[alpha,ssr,R2,resid,Sigma] = fpostest(y,x,z,regime);
m = length(regime)-2;
% 3. Present results

beta1 = cumsum(theta1);
beta2 = alpha2beta(reshape(alpha(1:(m+1)*p),p,m+1)',regime);
figure(1), subplot(311), plot(b),title('True value');
subplot(312),plot(beta1),title('GFL'); %legend('\beta_0','\beta_1'), set(gca,'xtick',[]),legend boxoff,axis([0 T 0 3]),% line([30 30],[0 3],'Color','g'), line([70 70],[0 3],'Color','g')
subplot(313),plot(beta2), title('GFL with post estimation');%,legend('\beta_0','\beta_1'),legend boxoff; axis([0 T 0 3]), %line([30 30],[0 3],'Color','g'), line([70 70],[0 3],'Color','g')

figure(2), plot(L,cv); xlabel('\lambda'); ylabel('Cross-validation error')
