function [alpha,ssr,R2,resid,Sigma] = fpostest(y,x,z,regime)
% y = x_t' * beta_t + z_t' * gamma + u_t
% Input: 
%   y: n-by-1 vector, the dependent variable
%   x: n-by-p matrix, the independent variables that may have time-varying
%           effects on y
%   z: n-by-q matrix, the independent variables that have constant effects
%   regime: a (m+2)-by-1 vector, containing {1,T1,...,Tm,n+1}, where
%           T1,...,Tm are m breaks.
% Output:
%   alpha: [(m+1)*p+q]-by-1 vector containing estimates for beta_t and
%           gamma.
%   ssr: SSR
%   R2: the goodness-of-fit, R square
%   resid: the n-by-1 residual vector
%   Sigma: the [(m+1)*p+q]-by-[(m+1)*p+q] covariance matrix. 
% Junhui Qian
% junhuiq@gmail.com
% 2018.11.20

[n,p] = size(x);
q = size(z,2);

m = length(regime)-2;

X = zeros(n,(m+1)*p);
for j = 1:m+1
    X(regime(j):regime(j+1)-1,p*(j-1)+1:p*j) = x(regime(j):regime(j+1)-1,:);
end

Q = [X z];
Sqq = Q'*Q;
if cond(Sqq)>1e10
    Sqq = Sqq+1e-10*eye((m+1)*p+q);
end
alpha = Sqq\(Q'*y);
resid = y-Q*alpha;
ssr = resid'*resid;
R2 = 1 - ssr/((y-mean(y))'*(y-mean(y)));
s2 = ssr/(n-(m+1)*p-q);
Sigma = s2*inv(Sqq);

end