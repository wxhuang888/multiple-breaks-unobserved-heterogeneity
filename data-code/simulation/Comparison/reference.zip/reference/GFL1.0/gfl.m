function [regime,alpha,Sigma,R2,ssr,resid]=gfl(y,x,z,option)
% [regime,alpha,Sigma,R2,ssr,resid]=gfl(y,x,z,option)
% Estimate time-series regression with an unknown number of structural
% breaks using the group-fused-Lasso (GFL) procedure proposed in Qian and
% Su (2016). The targeted model is given by,
%   y = x_t' * beta_t + z_t' * gamma + u_t
% Inputs:
%   y:      explained variable (n by 1)
%   x:      explanatory variables with time-varying effect (n by p)
%   z:      (optional) explanatory variables without time-varying effect (n by q)
%   option: (optional) some options. If the procedure does not work on some 
%               computers, set option.mex=0. 
%       option.date: (optional) a n-by-1 cell array of dates.
%       option.lambda: (optional) the tuning parameter on the GFL penalty,
%           if option.lambda='ic' (default), then lambda will be chosen
%           by information criterion. If option.lambda='cv', then lambda will
%           be chosen by cross-validtion.
%       option.L: (optional) the set of lambda's to be considered in the
%           automatic selection of option.lambda. The default setting is
%           option.L=[], in which case the procedure will generate one.
%       option.XTol: (optional) The error tolerance level, a small positive
%           number. The default choice is 1e-6;
%       option.maxIter: (optional) The maximum number of iterations in the
%           the block-coordinate-descent (BCD) algorithm. The default 
%           choice is 1000.
%       option.minseg: (optional) The minimum length of segments. The
%           default choice is p+q+1;
%       option.mex: (optional) An integer indicating whether to use mex
%           implementation. The default choice is 1, using mex implementation.
%           If the code does not work (e.g., causing Matlab to crash), then
%           set option.mex=0, in which case the program will call a slower
%           but platform-independent version of the BCD code.  
% Outputs:
%   regime: an (m+2)-by-1 vector that contains m breaks. By convention,  
%           regime = {1,T1,...,Tm,n+1}, where T1 is the first break date, 
%           T2 the second break date, and so on.
%   alpha:  a (p*(m+1)+q)-by-1 vector of estimated coefficients. 
%   Sigma:  a (p*(m+1)+q)-by-(p*(m+1)+q) matrix of estimated covariance 
%           matrix. 
%   R2:     The usual goodness-of-it.
%   ssr:    a scalar, the sum of squared residuals.
%   resid:  an n-by-1 vector of residuals. 
% 
%   To see how the procedure can be applied, run test_gfl.m
%   Reference: Junhui Qian and Liangjun Su, 2016, Shrinkage estimation of 
%       regression models with multiple structural changes, Econometric 
%       Theory, 32 (6), 1376-1433, 2016. 
%   Contact: Junhui Qian, junhuiq@gmail.com
%   Last update: Dec 24, 2018

[n,p]=size(x);
if nargin < 3
    z=[];
end
q = size(z,2);

if nargin < 4 || isempty(option)
    date=cell(n,1);
    for i=1:n
        date{i}=num2str(i);
    end
    option.date = date;
    option.lambda='ic';
    option.L = [];
    option.weight=ones(n-1,1);
    option.XTol=1e-6;
    option.maxIter=1000;
    option.h=1;
    option.minseg=p+q+1;
    option.mex=1; % mex implementation is much faster, but may not work on some computers, in which case set mex=0. 
else
    if ~isfield(option,'date') || isempty(option.date)
        date=cell(n,1);
        for i=1:n
            date{i}=num2str(i);
        end
        option.date=date;
    end
    if ~isfield(option,'lambda') || isempty(option.lambda)
        option.lambda='ic';
    end
    if ~isfield(option,'L')
        option.L=[];
    end
    if ~isfield(option,'weight') || isempty(option.weight)
        option.weight=ones(n-1,1);
    end
    if ~isfield(option,'XTol') || isempty(option.XTol)
        option.XTol=1e-6;
    end
    if ~isfield(option,'maxIter') || isempty(option.maxIter)
        option.maxIter=1000;
    end
    if ~isfield(option,'h') || isempty(option.h)
        option.h=1;
    end
    if ~isfield(option,'minseg') || isempty(option.minseg)
        option.minseg=p+q+1;
    end
    if ~isfield(option,'mex') || isempty(option.mex)
        option.mex=1;
    end
    
end

if isnumeric(option.lambda)
    lambda = option.lambda;
    if option.mex
        theta = mfbcd(y,x,z,lambda,option.weight,option.XTol,option.maxIter); % fast version, platform-dependent
    else
        theta = fbcd(y,x,z,lambda,option.weight,option.XTol,option.maxIter); % slower version, platform-independent
    end
    regime = findbreaks(theta,option.h);
    [alpha,ssr,R2,resid,Sigma] = fpostest(y,x,z,regime);
elseif strcmp(option.lambda,'ic')
    [regime,alpha,R2,Sigma,ssr,resid] = gfl_ic(y,x,z,option);
elseif strcmp(option.lambda,'cv') || strcmp(option.lambda,'cross-validation') 
    [regime,alpha,R2,Sigma,ssr,resid]=gfl_cv(y,x,z,option);
else
    disp('Invalid setting of option.lambda.');
end

if nargout==0
    m = length(regime)-2;
    beta = reshape(alpha(1:(m+1)*p),p,m+1)';
    Sigma_beta = Sigma(1:(m+1)*p,1:(m+1)*p);
    se_beta = reshape(sqrt(diag(Sigma_beta)),p,m+1)';
    t_beta = beta./se_beta;
    dof = repmat(diff(regime)-(p+q),1,p);
    pv_beta = 2*(1-tcdf(abs(t_beta),dof));
    disp('Group-Fused-Lasso estimation of time series regression with breaks');
    if isnumeric(option.lambda)
        disp('Lambda is chosen by: the user.');
    elseif strcmp(option.lambda,'ic')
        disp('Lambda is chosen by information criterion.');
    else
        disp('Lambda is chosen by cross-validation.');
    end
    disp('Estimated break dates and time-varying paramters in each regime:');
    disp('Regimes  \\\  Parameter Estimates   \\\      Standard Errors    \\\        P-values');
    for i=1:m+1
        disp([option.date{regime(i)} ' to ' option.date{regime(i+1)-1} ': \\\ ' num2str(beta(i,:)) ' \\\ ' num2str(se_beta(i,:))  ' \\\ ' num2str(pv_beta(i,:))]);
    end
    disp('');
    figure(1); plot(alpha2beta(beta,regime)), title('\beta_t'), xlabel('t'), ylabel('Parameter estimates');
    if q>0
        gamma = alpha((m+1)*p+1:(m+1)*p+q);
        Sigma_gamma = Sigma((m+1)*p+1:(m+1)*p+q,(m+1)*p+1:(m+1)*p+q);
        se_gamma = sqrt(diag(Sigma_gamma));
        t_gamma = gamma./se_gamma;
        dof = n-((m+1)*p+q);
        pv_gamma = 2*(1-tcdf(abs(t_gamma),dof));
        disp('Estimation of gamma');
        disp('\\\ Parameter Estimates   \\\        Standard Errors     \\\        P-values');
        disp(['\\\ ' num2str(gamma') ' \\\ ' num2str(se_gamma')  ' \\\ ' num2str(pv_gamma')]);
    end
    

end
