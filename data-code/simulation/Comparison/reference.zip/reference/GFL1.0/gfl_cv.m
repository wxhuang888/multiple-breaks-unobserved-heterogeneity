function [regime,alpha,R2,Sigma,ssr,resid,lambda,cv,L]=gfl_cv(y,x,z,option)

[n,p]=size(x);
if nargin < 3
    z=[];
end
q = size(z,2);

if nargin < 4 || isempty(option)
    option.L = [];
    option.weight=ones(n-1,1);
    option.XTol=1e-6;
    option.maxIter=1000;
    option.minseg=p+q+1;
    option.h = 1; % smoothing parameter in finding the breaks. Smaller h yields more breaks
    option.mex=1; % mex implementation is much faster, but may not work on some computers, in which case set mex=0. 
end

if isempty(option.L) || ~isfield(option,'L')
    S = 10;
    lam_max = get_max_lambda(y,x,z);
    lam_min = 0.05*lam_max;
    R = (0.8*lam_max-lam_min)/(S-1);
    option.L = lam_min+(0:1:S-1)'*R;
end
L = option.L;

nL = length(L);
cv = zeros(nL,1);
disp('It may take a long time. Please wait patiently.');
for i = 1:nL
    tmp = 0;
    for t = 1:n
        ix = [(1:t-1)';(t+1:n)'];
        y1 = y(ix);
        x1 = x(ix,:);
        if q>0 
            z1 = z(ix,:); 
        else
            z1 = [];
        end
        if option.mex
            theta = mfbcd(y1,x1,z1,L(i),option.weight,option.XTol,option.maxIter); % fast version, platform-dependent
        else
            theta = fbcd(y1,x1,z1,L(i),option.weight,option.XTol,option.maxIter); % slower version
        end
        regime = findbreaks(theta,option.h,option.minseg);
        alpha = fpostest(y1,x1,z1,regime);
        m = length(regime)-2;
        beta = alpha2beta(reshape(alpha(1:(m+1)*p),p,m+1)',regime);
        if q>0
            gamma = alpha((m+1)*p+1:(m+1)*p+q);
        end
        if t==1
            b = beta(t,:)';
        elseif t<n
            b = (beta(t-1,:)+beta(t,:))'/2;
        else
            b = beta(t-1,:)';
        end
        if q>0
            tmp = tmp + (y(t)-x(t,:)*b-z(t,:)*gamma)^2;
        else
            tmp = tmp + (y(t)-x(t,:)*b)^2;
        end
    end
    cv(i)=tmp;
end
[minr,i] = min(cv);
lambda = L(i);
if option.mex
    theta = mfbcd(y,x,z,L(i),option.weight,option.XTol,option.maxIter); % fast version, platform-dependent
else
    theta = fbcd(y,x,z,L(i),option.weight,option.XTol,option.maxIter); % slower version, platform-independent
end
regime = findbreaks(theta,option.h,option.minseg);
[alpha,ssr,R2,resid,Sigma] = fpostest(y,x,z,regime);




