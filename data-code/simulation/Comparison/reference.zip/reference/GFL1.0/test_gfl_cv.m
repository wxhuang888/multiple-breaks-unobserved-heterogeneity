clear all;

T = 120;
regime0 = [1; T/2+1; T+1];
alpha0 = [1 0.5;...
        0.5 1;];
p = size(alpha0,2);
b = alpha2beta(alpha0,regime0);
x = [ones(T,1) randn(T,p-1)];
s = sum(x.*b,2);

z = [0.5*randn(T,1)+0.5*x(:,2) randn(T,1) randn(T,1)];
gamma0 = [1 0.5 1]';

p = size(x,2);
q = size(z,2);

sigma = 0.5;
y = s+z*gamma0+sigma*randn(T,1);

[regime,alpha,R2,Sigma,ssr,resid,lambda,cv,L] = gfl_cv(y,x,z);
m = length(regime)-2;
beta = reshape(alpha(1:(m+1)*p),p,m+1)';
Sigma_beta = Sigma(1:(m+1)*p,1:(m+1)*p);
se_beta = sqrt(diag(Sigma_beta));

gamma = alpha((m+1)*p+1:(m+1)*p+q);
Sigma_gamma = Sigma((m+1)*p+1:(m+1)*p+q,(m+1)*p+1:(m+1)*p+q);
se_gamma = sqrt(diag(Sigma_gamma));

disp(regime');
figure(1), subplot(311), plot(L,cv);
subplot(312),plot(b);
subplot(313),plot(alpha2beta(beta,regime));

