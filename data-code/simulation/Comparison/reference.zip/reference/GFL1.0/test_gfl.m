T = 120;
regime0 = [1; T/2+1; T+1];
alpha0 = [1 0.5;...
        0.5 1;];
p = size(alpha0,2);
b = alpha2beta(alpha0,regime0);
x = [ones(T,1) randn(T,p-1)];
s = sum(x.*b,2);

z = [0.5*randn(T,1)+0.5*x(:,2) randn(T,1) randn(T,1)];
gamma0 = [1 0.5 1]';

p = size(x,2);
q = size(z,2);

sigma = 0.5;
y = s+z*gamma0+sigma*randn(T,1);

option.lambda='ic';
gfl(y,x,z,option);

