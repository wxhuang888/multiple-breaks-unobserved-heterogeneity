function [alpha,ssr,se] = post_pls(Y,X,N,regime)
% post lasso estimation without first differencing

%% initialization
[n,p]               = size(X);
T                   = n/N;
m                   = size(find(regime),1)-2;                               % number of breaks
nr                  = size(find(regime),1)-1;
%% estimation
if m == 0 
    alpha                                   = ((X'*X)\(X'*Y))';
else
    RX                                      = reshape(X,T,N,p);
    RY                                      = reshape(Y,T,N);
    for r = 2:nr+1
        regimeX                             = RX(regime(r-1):regime(r)-1,:,:);
        regimeY                             = RY(regime(r-1):regime(r)-1,:,:);
        XX                                  = reshape(regimeX,N*(regime(r)-regime(r-1)),p);
        YY                                  = reshape(regimeY,N*(regime(r)-regime(r-1)),1);
        alpha(r-1,:)                        = (XX'*XX)\(XX'*YY);
        clear regimeX regimeY XX YY
    end
end

% transform alpha to beta
[mbar,p]                                    = size(alpha);
beta                                        = zeros(regime(mbar+1)-1,p);
for i = 1:mbar
    beta(regime(i):regime(i+1)-1,:)         = repmat(alpha(i,:),regime(i+1)-regime(i),1);
end
res                                         = Y - sum(X .* repmat(beta,N,1),2);
ssr                                         = res'*res;

%% standard deviation estimate
if nargout > 2        
    RX                          = reshape(X,T,N,p);    
    RY                          = reshape(Y,T,N);      
    Rres                        = reshape(res,T,N);                
    if m == 0            
        XX                      = reshape(X,N*T,p);                
        YY                      = reshape(Y,N*T,1);               
        rres                    = reshape(res,N*T,1);        
        xi                      = repmat(rres,1,p).*XX;           
        Omega                   = (xi'*xi)/(N*T);        
        Phi                     = (XX'*XX)/(N*T)\eye(p);        
        S                       = Phi*Omega*Phi'/(N*T);        
        se                      = reshape(sqrt(diag(S)),1,p);
    else        
        for r = 2:nr+1
            tau                 = regime(r)-regime(r-1);
            regimeX             = RX(regime(r-1):regime(r)-1,:,:);                
            regimeY             = RY(regime(r-1):regime(r)-1,:);                
            regimeres           = Rres(regime(r-1):regime(r)-1,:);                
            XX                  = reshape(regimeX,N*(regime(r)-regime(r-1)),p);        
            YY                  = reshape(regimeY,N*(regime(r)-regime(r-1)),1);       
            rres                = reshape(regimeres,N*(regime(r)-regime(r-1)),1);
            xi                  = repmat(rres,1,p).*XX;   
            Omega               = (xi'*xi)/(N*tau);
            Phi                 = (XX'*XX)/(N*tau)\eye(p);
            S                   = Phi*Omega*Phi'/(tau*N);
            se(r-1,:)           = reshape(sqrt(diag(S)),1,p);                        
            clear regimeX regimeY regimeres XX YY rres XU S
        end        
    end
end
