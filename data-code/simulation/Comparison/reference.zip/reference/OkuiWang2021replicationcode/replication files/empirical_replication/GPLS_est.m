function [est_regime, est_alpha, est_se, est_group, resQ_best, lambda] = GPLS_est(idxdata,G,beta_init,gi_init,option)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function computes the GAGFL estimates of group memberships, 
% break points, and slope coefficients. 
%
% Input: 
% idxdata = dataset containing ID, TIME, Y, X
% G = the number of groups
% beta_init = initial estimates of fully time-varying coefficients
% gi_init = initial group membership estimates
% option = option for AGFL algorithm
%
% Output:
% est_regime = estimated regime (break points)
% est_alpha = estimate coefficients in each regime
% est_se = standard error of est_alpha
% est_group = estimated group memberships
% resQ_best = sum of squared residuals
% num_iter = number of iterations
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N                               = idxdata.N(end); 
T                               = size(idxdata,1)/N;
K                               = size(idxdata.X,2);
Y                               = idxdata.y;
X                               = idxdata.X;

%% initialization
gi_auxaux                       = zeros(N,G);
Nsim                            = 1;                                        % number of simulations
resQ_best                       = 10^7;                                     % sum of squared residuals for the best initial values
max_iteration                   = 20;

%% estimation
for jsim = 1:Nsim                                                           % Nsim = 1 no different random initialization 
    gi                          = gi_init;    
    par_init                    = zeros(N*T,K);
    deltapar                    = 1;                                        % iteration indicator   
    num_iter                    = 0;                                        % number of iterations
    while deltapar > 0 && num_iter < max_iteration                          % iterated optimization                
        %% step 1: update          
        for g = 1:G 
            NN                  = 1:N;
            gi                  = logical(gi);
            this_group          = gi(:,g);    
            g_index             = NN(this_group);    
            g_data              = idxdata(ismember(idxdata.N,g_index),:);   % group-specific data	
            Ng                  = sum(gi(:,g));                             % number of individuals within this group
            gX                  = g_data.X;
            gy                  = g_data.y;
            gbeta_init          = reshape(beta_init(g,:)',T,K);
            [regime,alpha,~,~,~,~,lambda(g)] = pls(gy,gX,Ng,gbeta_init,option);     % penalized least square for each group            
            [numbk(g),~]        = size(alpha);                              % number of breaks     
            for i = 1:numbk(g)                                              % transform alpha to beta
                for k = 1:K         
                    beta(g,regime(i):regime(i+1)-1,k) ...,
                        = repmat(alpha(i,k),regime(i+1)-regime(i),1)';      % beta: G*T*K matrix, time-varying coefficient for each group 
                end
            end
        end
        
        %% step 2: group assignment
        for g = 1:G    
            beta_group_temp     = reshape(beta(g,:,:),T,K);        
            beta_group          = kron(ones(N,1),beta_group_temp);          % beta of the g-th group                            
            U                   = (Y-sum(X.*beta_group,2)).^2;              % squared residual using beta of the g-th group  
            RU                  = reshape(U,T,N)';                   
            gi_auxaux(:,g)      = sum(RU')';                                % time summation of squared residual for the g-th group
        end    
        [gi_class, gindt]       = min(gi_auxaux,[],2);                      % for each individual, find the group with least sum of squared residual
        for g = 1:G
            gi(:,g)             = (gi_auxaux(:,g) == gi_class);             % assign each individual to the optimal group       
        end

        %% check convergence
        par_new                 = zeros(N*T,K);                       
        for i = 1:N
            par_new_indiv       = beta(gindt(i),:,:);                       % updated parameter for each individual 
            par_new((i-1)*T+1:i*T,:) = permute(par_new_indiv,[2,3,1]);      % updated parameter
        end
        deltapar                = norm(par_new-par_init);                   % update iteration indicator: check norm between updated and initial parameter
        par_init                = par_new;    
        num_iter                = num_iter + 1;
    end
    resQ                        = (Y-sum(X.*par_new,2))'*(Y-sum(X.*par_new,2));                  
    if resQ < resQ_best
        resQ_best               = resQ;
        gi_best                 = gi;
        beta_best               = beta;
        par_best                = par_new;
    end        
end

%% final estimate
maxnumbk                        = max(numbk);                               % maximum number of breaks for all groups
maxnumreg                       = maxnumbk+1;                               % maximum number of regimes for all groups
est_group                       = gi_best;
est_alpha                       = zeros(maxnumbk,K,G);
est_se                          = zeros(maxnumbk,K,G);
est_regime                      = zeros(maxnumreg,G);
for g = 1:G  
    NN                          = 1:N;    
    est_group                   = logical(est_group);    
    this_group                  = est_group(:,g);        
    g_index                     = NN(this_group);        
    g_data                      = idxdata(ismember(idxdata.N,g_index),:);   % group-specific data	    
    Ng                          = sum(est_group(:,g));                      % number of individuals within this group    
    gX                          = g_data.X;    
    gy                          = g_data.y;
    gbeta_init                  = reshape(beta_init(g,:)',T,K);
    [regime,alpha,se,ssr,~,~,~] = pls(gy,gX,Ng,gbeta_init,option);          % penalized least square for each group   
    [numbk(g),~]                = size(alpha);                              % number of breaks     
    est_alpha(1:numbk(g),:,g)   = alpha;
    est_se(1:numbk(g),:,g)      = se;
    est_regime(1:numbk(g)+1,g)  = regime;
end

end

 