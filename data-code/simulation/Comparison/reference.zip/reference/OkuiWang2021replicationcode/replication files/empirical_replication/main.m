clear
clc
warning off;

%% load data
data        = xlsread('demo_inc.xlsx');
N           = 90;
T           = 7;
democ       = data(:,1);
lagdemoc    = data(:,2);
income      = data(:,3);
Y           = democ;
X           = [ones(N*T,1) lagdemoc income];
K           = size(X,2);

%% normalization 
Y           = (Y-repmat(mean(Y),N*T,1))./std(Y);
X(:,2:K)    = (X(:,2:K)-repmat(mean(X(:,2:K)),N*T,1))./repmat(std(X(:,2:K)),N*T,1);
time        = repmat(1:T,1,N)';                            
id          = reshape(repmat(1:N,T,1),N*T,1);
idxdata     = dataset(id, time, Y, X);    
idxdata.Properties.VarNames = {'N'  'T'  'y'  'X'};     
G           = 4;  

%% GAGFL estimation
option.maxLambda        = 50;     
option.minLambda        = 0.001;     
option.nGrid            = 200;
% [beta_init,gi_init,Qr]  = gfe_est(idxdata,G);                               % initial estimates using GFE
% Since the gfe algorithm depends on the initial values, to exactly 
% replicate the empirical results, use the saved initial gfe estimates
load gfe_init.mat
[est_regime, est_alpha, est_se, est_group, resQ ,lambda] = GPLS_est(idxdata,G,beta_init,gi_init,option); % grouped penalized least square (heterogeneous breaks)

