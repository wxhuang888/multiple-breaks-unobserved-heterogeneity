/*********************************************************************
 * cplsbcd.c
 * This program implements the BCD (Block-Coordinate Descent) algorithm of 
 * PLS estimation of panel data model without first differencing.
 * tht = cplsbcd(y,x,lambda,weight,XTol,maxIter);
 *  Output: 
 *      y: lhs variable, an n by 1 column vector
 *  Inputs:
 *      x: rhs variables, an n by m matrix
 *      lambda: tuning parameter, scalar
 *      weight: weighting vector, (n-1) by 1
 *      XTol: error tolerance, scalar
 *      maxIter: max num of iterations, scalar integer
 *  Subroutines needed:
 *      nrutil.c mnbrak.c brent.c gaussj.c
 *  To compile mex program, enter the following statement in Maltab:
 *      >> mex cplsbcd.c nrutil.c mnbrak.c brent.c gaussj.c

 ********************************************************************/
#include <matrix.h>
#include <mex.h>   
#include <math.h>
#include "nrutil.h"

/* Definitions to keep compatibility with earlier versions of ML */
#define NRANSI

#ifndef MWSIZE_MAX
typedef int mwSize;
typedef int mwIndex;
typedef int mwSignedIndex;

#if (defined(_LP64) || defined(_WIN64)) && !defined(MX_COMPAT_32)
/* Currently 2^48 based on hardware limitations */
# define MWSIZE_MAX    281474976710655UL
# define MWINDEX_MAX   281474976710655UL
# define MWSINDEX_MAX  281474976710655L
# define MWSINDEX_MIN -281474976710655L
#else
# define MWSIZE_MAX    2147483647UL
# define MWINDEX_MAX   2147483647UL
# define MWSINDEX_MAX  2147483647L
# define MWSINDEX_MIN -2147483647L
#endif
#define MWSIZE_MIN    0UL
#define MWINDEX_MIN   0UL
#endif

void cumsum(double *x, int n, int p, double *ans)
{
    double sum;
    int i, j;

    for(j=0; j<p; j++) { 
        sum = 0.0;
        for( i=0 ; i<n ; i++) {
        	sum = sum+x[j*n+i];
            ans[j*n+i] = sum;
        }
    }
}

void invshift(double *x, int n, int p, double *y)
{
    int i, j;
    for(j=0;j<p;j++){
        for(i=0;i<n;i++){
            y[j*n+i] = x[j*n+(n-i-1)];
        }
    }
}

void fillzero(double *x,int n)
{
    int i;
    for(i=0;i<n;i++)
        x[i]=0;
}

void getrow(double *b,int n, int p, int row, double *q)
{
    int i;
    for(i=0;i<p;i++)
        q[i] = b[n*i+row];
}

void getrow2(double *Rn,int n,int p,int row,double *A)
{
    int l,m;
    for(l=0;l<p;l++){
        for(m=0;m<p;m++)
            A[l*p+m] = Rn[n*(l*p+m)+row];
    }
}

double func(double gam, const double *R, int p, const double lam, const double *g){
    int i;
    double *A, *q, sum;
    
	if(gam<0)
		return 1e+6;

    A = dvector(1,p*p);
    q = dvector(1,p);
    for(i=0;i<p*p;i++)
        A[i] = gam*R[i];
    for(i=0;i<p;i++)
        A[i*p+i] = A[i*p+i]+lam*lam/2;
    for(i=0;i<p;i++)
        q[i] = g[i];
    gaussj(A, p, q, 1);
    sum=0;
    for(i=0;i<p;i++)
        sum = sum + g[i]*q[i];
    free_dvector(A,1,p*p);
    free_dvector(q,1,p);
    return gam*(1-0.5*sum);
}

double norm2(double *x, int n)
{
    int i;
    double sum=0;
    for(i=0;i<n;i++)
        sum = sum + pow(x[i],2);
    return sqrt(sum);
}

void mtimesv(double *a, int n, int p, double *b, double *c)
{
    int i,j;
    double sum;
    for(i=0;i<n;i++){
        sum = 0;
        for(j=0;j<p;j++)
            sum = sum + a[j*n+i]*b[j];
        c[i]=sum;
    }
    
}


void wmbcd(double *y, double *x, int N,int T, int p, double *lambda, double *weight, double *XTol, double *maxIter, double *b)
{
    double *A,*q,*err,*S_xx,*S_xy; 
    double dTmp,lam;
    double *R,*Rn,*rv,*rvn;
    double *b0,*s,*c,*g;
    double *vTmp, *mTmp;
    int i,j,k,m,n,l,t;
    double ax,bx,cx,fa,fb,fc,xmin,errn,tmp1;
    
    ax = 1e-16; bx = 1e+6;
    n = N*T;
    
    S_xx    = dvector(1,T*p*p);
    S_xy    = dvector(1,T*p);

    A = dvector(1,p*p);
    q = dvector(1,p);
    R = dvector(1,T*p*p);
    Rn = dvector(1,T*p*p);
    rv = dvector(1,T*p);
    rvn = dvector(1,T*p);
    b0 = dvector(1,T*p);
    s = dvector(1,T*p);
    c = dvector(1,T*p);
    g = dvector(1,T*p);
    vTmp = dvector(1,p);
    mTmp = dvector(1,p*p);
    err = dvector(1,T*p);
    

    for(i=0;i<T;i++){
        for(j=0;j<p;j++){
            for(k=0;k<p;k++){
                tmp1=0; 
                for(l=0;l<N;l++){
                    tmp1 = tmp1 + x[j*T+l*T+i]*x[k*T+l*T+i];
                }
                S_xx[T*(k*p+j)+i] = tmp1/N;
            }
        }
    }

    for(i=0;i<T;i++){
        for(j=0;j<p;j++){
            tmp1=0; 
            for(l=0;l<N;l++){
                tmp1 = tmp1 + x[j*T+l*T+i]*y[l*T+i];
            }
            S_xy[T*j+i] = tmp1/N;
        }
    }

    invshift(S_xx,T,p*p,Rn);
    cumsum(Rn,T,p*p,R);
    invshift(R,T,p*p,Rn);
    
    invshift(S_xy,T,p,rvn);
    cumsum(rvn,T,p,rv);
    invshift(rv,T,p,rvn);
    
	fillzero(b0,T*p);
    errn=1e+10; 
    i = 0;
    while(errn>*XTol && i<*maxIter){
        i=i+1;
        for(j=0;j<T;j++){
            if(j==0){
                fillzero(s,T*p);
                fillzero(c,T*p);
                fillzero(g,T*p);
                /*  Equivalent Matlab code:
                 *  for j = 2:T
                        s(1,:) = s(1,:) + (reshape(Rn(j,:),p,p)*d0(j,:)')';
                    end                                       */
                for(k=1;k<T;k++){
                    getrow2(Rn,T,p,k,A);
                    getrow(b0,T,p,k,q);
                    mtimesv(A,p,p,q,vTmp);
                    for(m=0;m<p;m++)
                        s[m*T] = s[m*T]+vTmp[m];
                }
                
                /*  Equivalent Matlab code:
                 * g(1,:) = s(1,:) - rn(1,:);                 */
                for(k=0;k<p;k++){
                    g[k*T] = s[k*T]-rvn[k*T];
                }
                
                /* Equivalent Matlab code:
                 * d1(1,:) = -(reshape(Rn(1,:),p,p)\g(1,:)')';  */               
                getrow2(Rn,T,p,0,A);
                getrow(g,T,p,0,q);
                gaussj(A, p, q, 1);
                for(k=0;k<p;k++)
                    b[k*T] = -q[k];
                
            }else{
                /*  Equivalent Matlab code:
                 * c(nn,:) = c(nn-1,:) + d1(nn-1,:);               */
                for(k=0;k<p;k++)
                    c[k*T+j] = c[k*T+j-1] + b[k*T+j-1];
                
                /*  Equivalent Matlab code:
                 * s(nn,:) = s(nn-1,:) - (reshape(Rn(nn,:),p,p)*d0(nn,:)')';  */
                getrow2(Rn,T,p,j,A);
                getrow(b0,T,p,j,q);
                mtimesv(A,p,p,q,vTmp);
                for(k=0;k<p;k++)
                    s[k*T+j] = s[k*T+j-1] - vTmp[k];

                /* Equivalent Matlab code:
                 * g(nn,:) = (reshape(Rn(nn,:),p,p)*c(nn,:)' + s(nn,:)' - rn(nn,:)')';  */
                getrow(c,T,p,j,q);
                mtimesv(A,p,p,q,vTmp);
                for(k=0;k<p;k++)
                    g[k*T+j] = vTmp[k] + s[k*T+j] - rvn[k*T+j];
                /* Equivalent Matlab code:
                 * if norm(g(nn,:))<=lambda    d1(nn,:) = 0; */
                for(k=0;k<p;k++)
                    vTmp[k] = g[k*T+j];
                dTmp = norm2(vTmp,p);
                if(dTmp <= (*lambda)*weight[j-1]){
                    for(k=0;k<p;k++)
                        b[k*T+j]=0;
                }else{
                /* Equivalent Matlab code:
                 * [gam,fval,exitflag] = fminbnd(@myfun2,0,1e10,[],reshape(Rn(nn,:),p,p),lambda,g(nn,:)'); */
                    for(k=0;k<p;k++)
                        vTmp[k] = g[k*T+j];
                    lam = (*lambda)*weight[j-1];
                    mnbrak(&ax,&bx,&cx,&fa,&fb,&fc,A,p,lam,vTmp,func);
                    brent(ax,bx,cx,A,p,lam,vTmp,func,*XTol,&xmin);
                /* Equivalent Matlab code:
                 * d1(nn,:) = -gam*((gam*reshape(Rn(nn,:),p,p) + lambda^2/2*eye(p))\g(nn,:)')'; */    
                    for(k=0;k<p*p;k++)
                        A[k] = xmin*A[k];
                    for(k=0;k<p;k++)
                        A[k*p+k] = A[k*p+k]+lam*lam/2;
                    getrow(g,T,p,j,q);
                    gaussj(A,p,q,1);
                    for(k=0;k<p;k++)
                        b[k*T+j]=-xmin*q[k];
                }
            }
        }
        for(k=0;k<T*p;k++){
            err[k]=b[k]-b0[k];
            b0[k]=b[k];
        }
        errn = norm2(err,T*p);
    }

    free_dvector(A,1,p*p);
    free_dvector(q,1,p);
    free_dvector(S_xx,1,T*p*p);
    free_dvector(S_xy,1,T*p);
    free_dvector(R,1,T*p*p);
    free_dvector(Rn,1,T*p*p);
    free_dvector(rv,1,T*p);
    free_dvector(rvn,1,T*p);
    free_dvector(b0,1,T*p);
    free_dvector(s,1,T*p);
    free_dvector(c,1,T*p);
    free_dvector(g,1,T*p);
    free_dvector(vTmp,1,p);
    free_dvector(mTmp,1,p*p);
    free_dvector(err,1,T*p);
    

}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{

//declare variables
    #define b_out       plhs[0]
    #define y_in        prhs[0]
    #define x_in        prhs[1]
    #define lambda_in   prhs[2]
    #define weight_in   prhs[3]
    #define XTol_in     prhs[4]
    #define maxIter_in  prhs[5]

    const mwSize *dims;
    double *y,*x,*lambda,*weight,*XTol,*maxIter,*b;
    int n, p, N, T;
    
//figure out dimensions
    dims = mxGetDimensions(x_in);
    n = (mwSize)dims[0]; p = (mwSize)dims[1];
    dims = mxGetDimensions(weight_in);
    T = (mwSize)dims[0]; T = T+1;
    N = n/T; 

//associate outputs
    b_out = mxCreateDoubleMatrix(T,p,mxREAL);
    
//associate pointers
    y = mxGetPr(y_in);
    x = mxGetPr(x_in);
    lambda = mxGetPr(lambda_in);
    weight = mxGetPr(weight_in);
    XTol = mxGetPr(XTol_in);
    maxIter = mxGetPr(maxIter_in);
    b = mxGetPr(b_out);
    
    wmbcd(y,x,N,T,p,lambda,weight,XTol,maxIter,b);
    
    return;
}

