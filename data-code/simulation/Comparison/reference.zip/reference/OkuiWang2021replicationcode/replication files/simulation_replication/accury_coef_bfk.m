function [mse, medse, reldev, coverage] = accury_coef_bfk(est_coef, est_se, alpha0, regime0, group0)
%% full vector of coefficient for each individual (T*1)

K   = size(est_coef,2);
if K == 1
    for g = 1:size(regime0,2)
        alpha0_full                  = [];
        for i = 2:length(regime0(:,g))    
            alpha0_full              = [alpha0_full; repmat(alpha0(i-1,g),regime0(i,g)-regime0(i-1,g),1)];
        end
        alpha0_full_group(:,g)       = alpha0_full;                             % true coefficient alpha0
    end    
else    
    for g = 1:size(regime0,2)    
        alpha0_full                  = [];    
        for i = 2:length(regime0(:,g))            
            alpha0_full              = [alpha0_full; repmat(alpha0(i-1,:,g),regime0(i,g)-regime0(i-1,g),1)];    
        end        
        alpha0_full_group(:,:,g)       = alpha0_full;                             % true coefficient alpha0
    end
end
%% assign the coefficient vector to all individuals
[~,col0]                         = max(group0');                            % true group membership for each individual
coef0                            = [];
if K == 1
    for i = 1:length(col0)
        coef0                    = [coef0; alpha0_full_group(:,col0(i))];   % true coefficient vector
    end
else
    for i = 1:length(col0)
        coef0                    = [coef0; alpha0_full_group(:,:,col0(i))];   % true coefficient vector
    end
end
N                                = length(group0);
T                                = regime0(end)-1;
%% mean and median squared error
mse                              = mean((est_coef - coef0).^2);
medse                            = median((est_coef - coef0).^2);
reldev                           = mean((abs(est_coef - coef0)./coef0));

%% coverage    
cover                            = est_coef-1.96.*est_se <= coef0 & coef0 <= est_coef+1.96.*est_se;
coverage                         = sum(cover)/(N*T);

end
