function [SSR,bhat,sehat] = bfk_post_break_est(N,T,Y,X)
% T = time
% N = countries
K     = size(X,3);
OX    = reshape(X,T*N,K);
X_tot = repmat(OX,1,N).*kron(eye(N),ones(T,K));
Y_vec = reshape(Y,N*T,1);
bhat  = (X_tot'*X_tot)\(X_tot'*Y_vec);   
Yhat  = repmat(repmat(bhat',T,1),N,1).*kron(eye(N),ones(T,K)).*X_tot;
Yhat  = sum(Yhat,2);
SSR   = (Y_vec-Yhat)'*(Y_vec-Yhat)/(N*T);
                        
xi    = repmat((Y_vec-Yhat),1,K*N).*X_tot;   
Omega = (xi'*xi)/(N*T);
Phi   = (X_tot'*X_tot)/(N*T)\eye(N*K);
S     = Phi*Omega*Phi'/(T*N);
sehat = reshape(sqrt(diag(S)),N*K,1);                        

end

