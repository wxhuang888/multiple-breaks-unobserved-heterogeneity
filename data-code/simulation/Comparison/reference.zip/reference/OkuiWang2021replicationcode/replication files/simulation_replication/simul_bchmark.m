%% This is the main script for simulation DGP.1 %%
clear
clc
warning off; 

%% parameterization
N                = 100;
T                = 20;
sigma            = 0.5;                                                     % standard deviation of error term
N1               = round(N/3);                                              % number of units in group 1
N2               = round(N/3);                                              
N3               = N-N1-N2;
K                = 1;                                                       % number of regressors
G0               = 3;                                                       % number of groups
R                = 10;                                                    % number of replications

%% true regimes and groups
regime0          = [1 round(T/2) round(T/2)+round(T/3) T+1; ...,
                    1 T+1 0 0; ...,
                    1 round(T/3) round(T/2)+round(T/3) T+1;]';              % true regime (break points)
group0           = [[ones(N1,1); zeros(N-N1,1)] ...,
                    [zeros(N1,1); ones(N2,1); zeros(N3,1)]...,
                    [zeros(N1+N2,1); ones(N3,1)]];                          % true grouping                                                           
alpha01          = [1; 2; 3];                                               % coefficient in the first group
alpha02          = [1.5; 1.5; 1.5];                                         % coefficient in the second group
alpha03          = [3; 4; 5];                                               % coefficient in the third group
alpha0           = [alpha01 alpha02 alpha03];
numcoef          = size(alpha0,1);
for g = 1:G0
    numbreak0(:,g)              = nnz(diff(alpha0(:,g))~=0);                % true number of breaks
end
for j = 1:size(alpha0,2)
    beta0_tmp                   = [];
    for i = 1:size(alpha0,1)
        beta0_tmp               = [beta0_tmp; kron(alpha0(i,j), ones(regime0(i+1,j)-regime0(i,j),1))];
    end
    beta0(:,j)                  = beta0_tmp;
end

%% initialization
rr                              = 1;
rrp                             = 1;
s                               = 1; 
corr_numbk                      = zeros(1,G0);
corr_numbk_pls                  = 0;
HD_ratio                        = -999*ones(R,G0);
HD_ratio_pls                    = -999*ones(R,1);

for r = 1:R                                                                 % replication       
    clear est_regime_sort est_regime est_alpha    
    %% data generation process                
    X                           = randn(N*T,K);        
    e                           = sigma*randn(N*T,1);        
    Y                           = zeros(N*T,1);        
    Y(1:N1*T,1)                 = sum(X(1:N1*T,:).*repmat(beta0(:,1),N1,K),2) + e(1:N1*T,1);        
    Y(N1*T+1:(N1+N2)*T,1)       = sum(X(N1*T+1:(N1+N2)*T,:) .* repmat(beta0(:,2),N2,K),2) + e(N1*T+1:(N1+N2)*T,1);        
    Y((N1+N2)*T+1:end,1)        = sum(X((N1+N2)*T+1:end,:) .* repmat(beta0(:,3),N3,K),2) + e((N1+N2)*T+1:end,1);     
    year                        = repmat(1:T,1,N)';        
    code                        = kron((1:N)',ones(T,1));        
    idxdata                     = dataset(code, year, Y, X);        
    idxdata.Properties.VarNames = {'N'  'T'  'y'  'X'};        
    G                           = G0;    
            
    %% estimation        
    option.maxLambda            = 100;         
    option.minLambda            = 0.01;         
    option.nGrid                = 40;    
    
    %--- pls estimation (common breaks)
    b_init                                 = post_pls(Y,X,N,(1:T+1)');      % initial estimate of beta    
    [regime_pls,alpha_pls,se_pls,~,~,~,~]  = pls(Y,X,N,b_init,option);      

    %--- gpls estimation
    est_regime                                                      = [];
    while isempty(est_regime)
        [beta_init,gi_init]                                         = gfe_est(idxdata,G);
        [est_regime,est_alpha,est_se,est_group,resQ,num_iter(r)]    = GPLS_est(idxdata,G,beta_init,gi_init,option); % grouped penalized least square (heterogeneous breaks)
    end      
    %--- ls break detection
    xmat    = reshape(X,T,N,K);
    ymat    = reshape(Y,T,N);
    zmat    = xmat;
    ifull   = 1;
    [est_break_pts_bfk, bhat_bfk, sehat_bfk]            = bfk_multi_break_detect(N,T,ymat,xmat,zmat,ifull);

    %% evaluation of GPLS     
    %--- group membership    
    for g = 1:G    
        gp_crowd(g)             = sum(find(group0(:,g)));                              
        est_gp_crowd(g)         = sum(find(est_group(:,g)));                  % relabel groups        
    end    
    [~,gindx_sort]              = sort(gp_crowd);    
    [~,est_gindx_sort]          = sort(est_gp_crowd);    
    group0_upt                  = group0(:,gindx_sort);    
    est_group_upt               = est_group(:,est_gindx_sort);    
    group0_sort                 = group0_upt;    
    est_group_sort              = est_group_upt;       
    accur_class(r)              = accury_class(group0_sort,est_group_sort,N); % classification accuracy
    
    %--- number of break points    
    est_numbreak                = zeros(1,G);
    for g = 1:G    
        est_numbreak(1,g)       = length(nonzeros(est_regime(:,g)))-2;        % estimated number of breaks for each group        
    end    
    est_numbreak_sort           = est_numbreak(est_gindx_sort);    
    numbreak0_sort              = numbreak0(gindx_sort);    
    for g = 1:G    
        if est_numbreak_sort(g) == numbreak0_sort(g)        
            corr_numbk(g)       = corr_numbk(g)+1;                            % count times of correct estimation of break number          
        end        
    end    
    est_numbreak_gpls(r,:)      = est_numbreak_sort;
    
    %--- accuracy of break point estimate    
    est_regime_sort             = est_regime(:,est_gindx_sort);    
    regime0_sort                = regime0(:,gindx_sort);       
    
    %--- bias of grouped coefficient estimate                                                                                
    est_alpha_sort              = est_alpha(:,:,est_gindx_sort);    
    est_alpha_sort              = permute(est_alpha_sort, [1 3 2]);    
    est_alpha_sort(~any(est_alpha_sort,2),:) = [];
    for g = 1:G    
        accur_break         = accury_bkdate(est_regime_sort(:,g),regime0_sort(:,g),est_numbreak_sort(g));                       
        HD_ratio(rr,g)      = accur_break./T;                               % ratio of Hausdoff distance        
    end
    if any(est_numbreak_sort == numbreak0_sort)
        rr                      = rr + 1;
    end
    
    %--- mean and median squared error of coefficient estimate
    [mse(r), medse(r), reldev(r), coverage(r)]              = accury_coef(est_regime, est_alpha, est_group, alpha0, regime0, group0, est_se); 
    
    %% evaluation of PLS
    %--- number of break points
    est_numbreak_pls(r)         = length(nonzeros(regime_pls))-2;             % estimated number of breaks
    if est_numbreak_pls(r) == max(numbreak0_sort)
        corr_numbk_pls          = corr_numbk_pls+1;                           % count times of correct estimation of break number 
    end
    
    %--- accuracy of break point estimate
    regime0_pls                 = [1 round(T/3) round(T/2) round(T/2)+round(T/3) T+1];
    accur_break_pls             = accury_bkdate(regime_pls,regime0_pls,est_numbreak_pls(r));                           
    HD_ratio_pls(r)             = accur_break_pls./T;                         % ratio of Hausdoff distance

    %--- mean and median squared error of coefficient estimate    
    [mse_pls(r), medse_pls(r), reldev_pls(r), coverage_pls(r)]  = accury_coef_pls(regime_pls, alpha_pls, alpha0, regime0, group0, se_pls); 
    

    %% evaluation of LS break detection
    regime_bfk              = [1 est_break_pts_bfk T+1];    
    accur_break_bfk         = accury_bkdate(regime_bfk,regime0_pls,3);
    HD_ratio_bfk(r)         = accur_break_bfk./T;                           % ratio of Hausdoff distance
    [mse_bfk(r), medse_bfk(r), reldev_bfk(r), coverage_bfk(r)]  = accury_coef_bfk(bhat_bfk, sehat_bfk, alpha0, regime0, group0); 

    r
end

%% save results
gplsEst.pct_corr_numbk             = corr_numbk./R;
gplsEst.numbk                      = mean(est_numbreak_gpls,1);
HD_ratio(HD_ratio == -999)         = NaN;
gplsEst.HD_ratio                   = nanmean(HD_ratio,1); 
gplsEst.missclass_rate             = mean(accur_class);
gplsEst.rmse                       = sqrt(mean(mse));
gplsEst.medse                      = mean(medse);
gplsEst.relmse                     = mean(reldev);
gplsEst.coverage                   = mean(coverage);
% gplsEst.alpha                      = sum(est_alpha_simul,3)./sum(est_alpha_simul~=0,3);
gplsEst.num_iter                   = mean(num_iter);

plsEst.numbk                       = mean(est_numbreak_pls);
plsEst.HD_ratio                    = nanmean(HD_ratio_pls,1); 
plsEst.pct_corr_numbk              = corr_numbk_pls./R;
plsEst.rmse                        = sqrt(mean(mse_pls));
plsEst.medse                       = mean(medse_pls);
plsEst.coverage                    = mean(coverage_pls);
plsEst.relmse                      = mean(reldev_pls);

bfkEst.HD_ratio                    = nanmean(HD_ratio_bfk); 
bfkEst.rmse                        = sqrt(mean(mse_bfk));
bfkEst.medse                       = mean(medse_bfk);
bfkEst.coverage                    = mean(coverage_bfk);
bfkEst.relmse                      = mean(reldev_bfk);

clearvars -except gplsEst plsEst bfkEst N T sigma
filename = ['Est_BM_N', num2str(N), '_T', num2str(T), '_sigma', num2str(sigma),'.mat'];
save(filename)
