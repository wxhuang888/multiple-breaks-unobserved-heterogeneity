function d = plsbcd(y,x,lambda,weight,XTol,maxIter)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% The block coordinated descent algorithm without using first differenced data
% 
% This code is modified based on the development of Qian and Su (2016).
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[n,p]           = size(x);
T               = length(weight)+1;
N               = n/T;

%% 
R               = zeros(T,p*p);
r               = zeros(T,p);

xtnp            = reshape(x,T,N,p);
ytn             = reshape(y,T,N);
for t = 1:T
    ax          = reshape(xtnp(t,:,:),N,p);
    ay          = reshape(ytn(t,:),N,1);   
    R(t,:)      = reshape(ax'*ax,1,p*p);
    r(t,:)      = ax'*ay;
end
Rn              = cumsum(R(T:-1:1,:));
Rn              = Rn(T:-1:1,:);
rn              = cumsum(r(T:-1:1,:));
rn              = rn(T:-1:1,:);

d0              = zeros(T,p);
d1              = zeros(T,p);

%%
e               = 1e10;
i               = 0;
while e>XTol && i<maxIter
    i           = i+1;
    for nn = 1:T
        if nn == 1
            s   = zeros(T,p);
            c   = zeros(T,p);
            g   = zeros(T,p);
            for j = 2:T
                s(1,:)      = s(1,:) + (reshape(Rn(j,:),p,p)*d0(j,:)')';
            end
            g(1,:)          = s(1,:) - rn(1,:);
            d1(1,:)         = -(reshape(Rn(1,:),p,p)\g(1,:)')';
        else
            c(nn,:)         = c(nn-1,:) + d1(nn-1,:);
            s(nn,:)         = s(nn-1,:) - (reshape(Rn(nn,:),p,p)*d0(nn,:)')';
            g(nn,:)         = (reshape(Rn(nn,:),p,p)*c(nn,:)' + s(nn,:)' - rn(nn,:)')';
            if norm(g(nn,:))<=lambda*weight(nn-1)
                d1(nn,:)    = 0;
            else
                [gam,~,exitflag]    = fminsearch(@myfun2,1,[],reshape(Rn(nn,:),p,p),lambda*weight(nn-1),g(nn,:)');
                if exitflag==1
                    d1(nn,:)        = -gam*((gam*reshape(Rn(nn,:),p,p) + (lambda*weight(nn-1))^2/2*eye(p))\g(nn,:)')';
                else
                    disp('Line search failed');
                    return;
                end
            end
        end
    end
    e           = norm(d1-d0);
    d0          = d1;
end
d               = d1;

function y = myfun2(gam,R,lam,g)
if gam < 0
    y           = 1e10;
    return;
end
p               = length(g);
y               = gam*(1-1/2*g'*((gam*R+lam^2/2*eye(p))\g));





