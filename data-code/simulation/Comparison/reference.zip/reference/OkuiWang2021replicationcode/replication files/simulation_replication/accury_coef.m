function [mse, medse, reldev, coverage] = accury_coef(est_regime, est_alpha, est_group, alpha0, regime0, group0, est_se)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function evaluates the accuracy of coefficient estimates
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% full vector of coefficient for each individual (T*1)
for g = 1:size(est_regime,2)
    alpha_full                          = [];
    alpha0_full                         = [];
    std_full                            = [];    
    for i = 2:nnz(est_regime(:,g))        
        alpha_full                      = [alpha_full; repmat(est_alpha(i-1,g),est_regime(i,g)-est_regime(i-1,g),1)];
        std_full                        = [std_full; repmat(est_se(i-1,g),est_regime(i,g)-est_regime(i-1,g),1)];    
    end
    for i = 2:length(regime0(:,g))        
        alpha0_full                     = [alpha0_full; repmat(alpha0(i-1,g),regime0(i,g)-regime0(i-1,g),1)];
    end
    alpha_full_group(:,g)               = alpha_full;                       % estimated coefficient hat{alpha}
    std_full_group(:,g)                 = std_full;                         % estimated std 
    alpha0_full_group(:,g)              = alpha0_full;                      % true coefficient alpha0
end
%% assign the coefficient vector to all individuals
[~,col]                                 = max(est_group');                  % estimated group membership for each individual
[~,col0]                                = max(group0');                     % true group membership for each individual
est_coef                                = [];
est_std                                 = [];
coef0                                   = [];
for i = 1:length(col)
    est_coef                            = [est_coef; alpha_full_group(:,col(i))];   % estimated coefficient vector
    est_std                             = [est_std; std_full_group(:,col(i))];    % estimated coefficient vector
    coef0                               = [coef0; alpha0_full_group(:,col0(i))];    % true coefficient vector
end
%% mean and median squared error
mse                                     = mean((est_coef - coef0).^2);
medse                                   = median((est_coef - coef0).^2);
reldev                                  = mean((abs(est_coef - coef0)./coef0));
%% coverage    
N                                       = length(group0);
nonzero                                 = find(est_regime(:,1));
T                                       = est_regime(nonzero(end),1)-1;
cover                                   = est_coef-1.96.*est_std <= coef0 & coef0 <= est_coef+1.96.*est_std;
coverage                                = sum(cover)/(N*T);
end
