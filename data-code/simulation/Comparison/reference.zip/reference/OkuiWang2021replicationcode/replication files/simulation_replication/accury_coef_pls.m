function [mse, medse, reldev, coverage] = accury_coef_pls(regime_pls, alpha_pls, alpha0, regime0, group0, se_pls)
%% full vector of coefficient for each individual (T*1)
for g = 1:size(regime0,2)
    alpha0_full                  = [];
    for i = 2:length(regime0(:,g))    
        alpha0_full              = [alpha0_full; repmat(alpha0(i-1,g),regime0(i,g)-regime0(i-1,g),1)];
    end
    alpha0_full_group(:,g)       = alpha0_full;                             % true coefficient alpha0
end
alpha_full                       = [];
std_full                         = [];    
for i = 2:length(regime_pls)                
    alpha_full                   = [alpha_full; repmat(alpha_pls(i-1),regime_pls(i)-regime_pls(i-1),1)];
    std_full                     = [std_full; repmat(se_pls(i-1),regime_pls(i)-regime_pls(i-1),1)];
end
%% assign the coefficient vector to all individuals
[~,col0]                         = max(group0');                            % true group membership for each individual
coef0                            = [];
for i = 1:length(col0)
    coef0                        = [coef0; alpha0_full_group(:,col0(i))];   % true coefficient vector
end
N                                = length(group0);
T                                = regime_pls(end)-1;
coef_pls                         = repmat(alpha_full,N,1);                  % estimated coefficient vector
std_pls                          = repmat(std_full,N,1);                  % estimated coefficient vector
%% mean and median squared error
mse                              = mean((coef_pls - coef0).^2);
medse                            = median((coef_pls - coef0).^2);
reldev                           = mean((abs(coef_pls - coef0)./coef0));

%% coverage    
cover                            = coef_pls-1.96.*std_pls <= coef0 & coef0 <= coef_pls+1.96.*std_pls;
coverage                         = sum(cover)/(N*T);

end
