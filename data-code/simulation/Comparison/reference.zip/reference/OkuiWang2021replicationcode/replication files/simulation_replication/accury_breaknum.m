function [bk_det] = accury_breaknum(est_m,m0)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This function return the accuracy of the number of breaks
%
% Input: 
% est_m: estimated number of breaks
% m0: true number of breaks
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
bk_det           = 0;
if m0 == 0                                                                  % if the truth is no break
    if sum(est_m ~= 0) ~= 0                                                 
        bk_det   = 1;                                                       % false-detection indicator
    end
else                                                                        
    bk_det_tmp   = (est_m == m0);                                           % check the break for each regressor 
    bk_det       = all(bk_det_tmp);                                         % correct-detection indicator (1 if correct for all regressors)
end

end

