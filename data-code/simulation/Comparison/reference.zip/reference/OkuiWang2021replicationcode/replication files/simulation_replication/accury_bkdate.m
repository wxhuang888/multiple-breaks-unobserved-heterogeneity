function [HD] = accury_bkdate(est_regime,regime0,est_numbk)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This function returns the Hausdorff distance, a measure of the 
% accuracy of the estimated break dates 
%
% Input: 
% est_regime: estimated regime
% regime0: true regime
% est_numbk: estimated number of breaks
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if est_numbk ~= 0 && length(find(regime0))-2 ~=0
        last_nonzero        = find(est_regime);
        last_nonzero        = last_nonzero(end);      
        last_nonzero0       = find(regime0);
        last_nonzero0       = last_nonzero0(end);              
        dista               = zeros(last_nonzero0-2,last_nonzero-2);
        for i = 2:last_nonzero0-1
            for j = 2:last_nonzero-1
                dista(i-1,j-1)   = abs(est_regime(j)-regime0(i));
            end
        end
        HD                  = max(max(min(dista)), max(min(dista')));       % Hausdorff distance
    else
        HD                  = 0;
    end
end

