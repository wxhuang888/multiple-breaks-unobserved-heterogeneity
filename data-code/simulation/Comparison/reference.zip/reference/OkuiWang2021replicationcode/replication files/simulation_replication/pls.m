function [regime,alpha,se,ssr,IC,K,lambda] = pls(Y,X,N,beta_init,option)
% This function estimate linear panel data model with multiple structural 
% breaks using AGFL in Qian and Su (2016). This code is modified based on
% the devleopement of Qian and Su (2016). 
%
% Inputs:
%   Y: dependent variable, NT by 1
%   X: independent variable, NT by p (p is the num of regressors)
%   N: number of cross-sections
%   option: a construct of options
%       option.maxLambda: maximum lambda
%       option.minLambda: minimum lambda
%       option.nGrid: number of grids on the range of lambda
%
% Outputs:  
%   regime: set of break points, regime = {1,tau_1,tau_2,...,tau_m,T+1}, m
%           is the number of break points. 
%   alpha:  estimated coefficients for each regime, (m+1) by p
%   se:     estimated standard error for each parameter, (m+1) by p
%   ssr:    sum of squared residuals
%   IC,K,lambda: for debug use only
  
%% parameters
[n,p]                       = size(X);
T                           = n/N;                                          % time dimension of balanced panel
lam_max                     = option.maxLambda;
lam_min                     = option.minLambda;
S                           = option.nGrid;                                 % number of total lambda's
R                           = log(lam_max/lam_min)/(S-1);
lambda                      = lam_min*exp(R*(0:S-1)');

%% initialization
IC                          = zeros(S,1);                                   % information criteria
K                           = zeros(S,1);                                   % number of breaks
THT                         = zeros(T,S*p);                                 % difference between two consecutive beta's
XTol                        = 1e-4;                                         % tolerance level
maxIter                     = 400;                                          % maximum iteration steps
% b                           = post_pls(Y,X,N,(1:T+1)');                     % initial estimate of beta
b                           = beta_init;
weight                      = norms(diff(b),p,3).^(-2);                     % adaptive weights

%% penalized least square
for i=1:S
    % tht                     = cplsbcd(Y,X,lambda(i),weight,XTol,maxIter);   % penalized least square (can also be estimated by plsbcd.m)
    tht                     = plsbcd(Y,X,lambda(i),weight,XTol,maxIter);   % penalized least square (can also be estimated by plsbcd.m)
    tht                     = reshape(tht,T,p);
    THT(:,p*(i-1)+1:p*i)    = tht;                                          % all theta's for different tuning parameters 
    regime                  = get_regime(tht,XTol);                          
    [tmp,ssr]               = post_pls(Y,X,N,regime);                       % post lasso estimation
    K(i)                    = length(regime)-2;                             % number of breaks
    IC(i)                   = ssr/(n-N) + 0.05*(K(i)+1)*p*log(N*T)/(N*T)^(1/2);
end
[tmp,i]                     = min(IC);                                      % choose the tunning parameter with minimum IC
theta                       = THT(:,p*(i-1)+1:p*i);

regime                      = get_regime(theta,XTol);
[alpha,ssr,se]              = post_pls(Y,X,N,regime);


