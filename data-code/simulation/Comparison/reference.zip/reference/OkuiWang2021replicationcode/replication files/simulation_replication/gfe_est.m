function [est_beta, est_group, resQ_best] = gfe_est(idxdata,G)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function computes the GFE-type estimates of group memberships and 
% fully time-varying slope coefficients. The estimates are used to compute 
% the adaptive weights and for the initialization of GAGFL algorithm.
%
% Input: 
% idxdata = dataset containing ID, TIME, Y, X
% G = the number of groups
%
% Output:
% est_beta = estimate fully time-varying coefficients 
% est_group = estimated group memberships
% resQ_best = sum of squared residuals
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
N                               = idxdata.N(end); 
T                               = size(idxdata,1)/N;
K                               = size(idxdata.X,2);
Y                               = idxdata.y;
X                               = idxdata.X;

%% initialization
gi_auxaux                       = zeros(N,G);
Nsim                            = 100;                                      % number of simulations
resQ_best                       = 10^7;                                     % sum of squared residuals for the best initial values
max_iteration                   = 20;

%% estimation
for jsim = 1:Nsim                                                           % use different initial values 
    % jsim
    gi_init                     = zeros(N,G);                                                   
    for i = 1:N                                                             % initialize a random group pattern
        perm                    = randperm(G);    
        for g = 1:G    
            gi_init(i,g)        = (perm(1)==g);        
        end    
    end
    gi                          = gi_init;    
    par_init                    = zeros(N*T,K);
        
    deltapar                    = 1;                                        % iteration indicator   
    num_iter                    = 0;                                        % number of iterations
    while deltapar > 0 && num_iter < max_iteration                          % iterated optimization
        % num_iter
        if ~all(sum(gi))
            for i = 1:N                                                     % if any group has no element, start a new random initialization
            perm                = randperm(G);    
                for g = 1:G    
                    gi_init(i,g) = (perm(1)==g);        
                end    
            end
            gi                  = gi_init;           
        end
        %% step 1: update          
        for g = 1:G 
            NN                  = 1:N;
            gi                  = logical(gi);
            this_group          = gi(:,g);    
            g_index             = NN(this_group);    
            g_data              = idxdata(ismember(idxdata.N,g_index),:);   % group-specific data	
            Ng                  = sum(gi(:,g));                             % number of individuals within this group
            gX                  = g_data.X;
            gy                  = g_data.y;
            gX_tot              = repmat(gX,1,T) .* repmat(eye(T),Ng,1);
            alpha               = (gX_tot'*gX_tot)\(gX_tot'*gy);            % time-by-time regression for each group
            beta(g,:,:)         = reshape(alpha,T,K);
        end
        
        %% step 2: group assignment
        for g = 1:G    
            beta_group_temp     = reshape(beta(g,:,:),T,K);        
            beta_group          = kron(ones(N,1),beta_group_temp);          % beta of the g-th group     
            U                   = (Y-sum(X.*beta_group,2)).^2;              % squared residual using beta of the g-th group  
            RU                  = reshape(U,T,N)';                   
            gi_auxaux(:,g)      = sum(RU')';                                % time summation of squared residual for the g-th group
        end    
        [gi_class, gindt]       = min(gi_auxaux,[],2);                      % for each individual, find the group with least sum of squared residual
        for g = 1:G
            gi(:,g)             = (gi_auxaux(:,g) == gi_class);             % assign each individual to the optimal group       
        end

        %% check convergence
        par_new                 = zeros(N*T,K);                       
        for i = 1:N
            par_new_indiv       = beta(gindt(i),:,:);                       % updated parameter for each individual 
            par_new((i-1)*T+1:i*T,:) = permute(par_new_indiv,[2,3,1]);      % updated parameter
        end
        deltapar                = norm(par_new-par_init);                   % update iteration indicator: check norm between updated and initial parameter
        par_init                = par_new;    
        num_iter                = num_iter + 1;
    end
    resQ                        = (Y-sum(X.*par_new,2))'*(Y-sum(X.*par_new,2));                  
    if resQ < resQ_best
        resQ_best               = resQ;
        gi_best                 = gi;
        beta_best               = beta;
    end        
end

%% final estimate
est_group                       = gi_best;
est_beta                        = beta_best;

end

 