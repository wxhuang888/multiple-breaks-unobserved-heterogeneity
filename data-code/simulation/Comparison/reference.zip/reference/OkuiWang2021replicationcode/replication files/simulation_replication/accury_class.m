function [mis_class] = accury_class(group0, est_group, N)
% This function computes the accuracy the classification
    
index                   = 1:N;
sumE                    = 0;
for g = 1:size(est_group,2)
    this_group0         = group0(:,g);
    est_this_group      = est_group(:,g);    
    this_group0         = logical(this_group0);    
    est_this_group      = logical(est_this_group);        
    g0_index            = index(this_group0);                               % individuals in the true group k
    estg_index          = index(est_this_group);                            % individuals in the estimated group k
    
    for i = 1:length(g0_index)
        EE(i,:)          = 1-any(g0_index(i) == estg_index);                % type I classification error
    end    
    sumE               = sum(EE)+sumE;
    clear EE
end
mis_class                = sumE/N;

end

