function y=maxc(x)

y=max(x);
y=y';