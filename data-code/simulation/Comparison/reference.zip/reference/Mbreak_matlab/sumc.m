function y=sumc(x)

y=sum(x,1);
y=y';