function beta=olsqr(y,x)

[beta,flag]=lsqr(x,y);