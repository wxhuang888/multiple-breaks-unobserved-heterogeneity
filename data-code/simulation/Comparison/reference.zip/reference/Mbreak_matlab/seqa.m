function seq=seqa(a,b,c)
       
seq=(a:b:(a+b*(c-1)))';

