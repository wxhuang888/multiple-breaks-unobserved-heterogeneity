function y=minc(x)

y=min(x);
y=y';