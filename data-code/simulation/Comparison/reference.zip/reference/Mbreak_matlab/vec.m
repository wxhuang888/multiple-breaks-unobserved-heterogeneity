function Y_big = vec(Y)

n = numel(Y) ;
Y_big = reshape(Y,[n,1]) ;