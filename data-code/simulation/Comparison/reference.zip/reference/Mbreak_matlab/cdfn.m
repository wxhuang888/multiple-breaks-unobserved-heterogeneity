function y=cdfn(x)

y=normcdf(x);