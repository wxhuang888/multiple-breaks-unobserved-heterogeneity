function y=rows(x)

y=size(x,1);