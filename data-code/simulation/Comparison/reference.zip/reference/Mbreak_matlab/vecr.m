function y=vecr(x)

xt=x';
y=xt(:);