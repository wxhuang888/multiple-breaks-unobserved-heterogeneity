function y=rndn(a,b)

y=randn(a,b);