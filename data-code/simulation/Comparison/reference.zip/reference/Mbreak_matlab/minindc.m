function index =minindc(x)

[mval,index]=min(x);
index=index';