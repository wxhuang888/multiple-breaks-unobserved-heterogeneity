function y=rev(x)

y=flipud(x);