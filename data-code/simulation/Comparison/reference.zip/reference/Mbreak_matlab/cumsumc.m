function y=cumsumc(x)

y=cumsum(x);