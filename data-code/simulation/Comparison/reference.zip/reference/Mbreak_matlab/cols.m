function y=cols(x)

y=size(x,2);