function y=sortc(x,col)
y=sortrows(x,col);