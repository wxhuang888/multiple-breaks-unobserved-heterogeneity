%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is the main file that reproduces the results in Tables 5 and 6.
%
% Please note that due to the randomness of initial values, a replication 
% may not be exactly identical to those in the paper. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear 
clc
warning off

[data,label]            = xlsread('data.xlsx');
id                      = data(:,1);
gvkey                   = data(:,2);
time                    = data(:,3);
gsale                   = data(:,4);
tobinsq                 = data(:,5);
lat                     = data(:,6);
lev                     = data(:,7);
cash                    = data(:,8);
ppe                     = data(:,9);
roa                     = data(:,10);
capex                   = data(:,11);
sic                     = data(:,12);

%% Data transformation
Xvec                    = [lev lat tobinsq cash ppe roa];                   
Yvec                    = gsale;
TT                      = 33;
N                       = length(Yvec)/TT;
K                       = size(Xvec,2);
for k = 1:K
    x(:,:,k)            = reshape(Xvec(:,k), TT, N)';
end
y                       = reshape(Yvec,TT,N)';
xlag                    = x(:,1:TT-1,:);
ylag                    = y(:,2:TT);
T                       = TT-1;
Xmat                    = xlag;
ymat                    = ylag;

%% Estimation with the estimated number of groups
GB                      = 5;                                                % number of groups before the break
GA                      = 7;                                                % number of groups after the break
B                       = 1;                                                % number of breaks
[k_lsbg,gpB_lsbg,gpA_lsbg,bB_lsbg,bA_lsbg,seB_lsbg,seA_lsbg,~]   = est_gpbk_fd_tvG(ymat,Xmat,B,GB,GA);
% k_lsbg = estimated break point
% gpB_lsbg = estimated group memberships before the break
% gpA_lsbg = estimated group memberships after the break
% bB_lsbg = estimated slope coefficients before the break
% bA_lsbg = estimated slope coefficients after the break
% seB_lsbg = estimated standard deviation before the break
% seA_lsbg = estimated standard deviation after the break
